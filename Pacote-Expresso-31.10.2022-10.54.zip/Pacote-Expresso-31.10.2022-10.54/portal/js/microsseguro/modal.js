﻿$('.arquivo').click(function (e) {
	e.preventDefault();

	var iframe = DefineIframeCartilha(e.currentTarget.getAttribute("data-pathFile"), e.currentTarget.getAttribute("data-fileName"), e.currentTarget.getAttribute("data-fileType"), e.currentTarget.getAttribute("data-type"));

	Swal.fire({
		showCloseButton: true,
		showConfirmButton: false,
		padding: "25px",
		width: "800px",
		confirmButtonColor: "#E31D41",
		confirmButtonText: "Avançar",
		html: iframe
	})
});

function DefineIframeCartilha(pathFile, fileName, fileType, type) {
	var iframeDelation = document.createElement("iframe");
	var basePath = "";
	if (location.hostname.indexOf("expresso.bradesco") >= 0) {
		basePath = "expresso.bradesco";
	} else {
		basePath = "expresso.predcd.bradesco.com.br";
	}
	var params = "pathFile=" + pathFile + "&fileName=" + fileName + "&fileType=" + fileType + "&type=" + fileType;

	iframeDelation.id = "iframeFormDelation";
	iframeDelation.src = "https:" + "//" + basePath + "/wsBradescoExpresso/VisualizacaoConteudo/Default.aspx?" + params;
	iframeDelation.frameBorder = 0;
	iframeDelation.scrolling = "no";
	iframeDelation.style.width = "100%";
	iframeDelation.style.height = "600px";

	return iframeDelation.outerHTML;
}

