﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!this.IsPostBack)
		{
			VisualizacaoVideoModels model = new VisualizacaoVideoModels();
			string pathFile = Request.QueryString["pathFile"];
			string fileName = Request.QueryString["fileName"];
			string fileType = Request.QueryString["fileType"];
			string type = Request.QueryString["type"];

			hdnPathFile.Value = (pathFile.EndsWith("/") ? pathFile : pathFile + "/");
			hdnFileName.Value = fileName;
			hdnFileType.Value = fileType.ToLower();
			hdnType.Value = type;
		}
	}

	protected void btnEnviar_Click(object sender, EventArgs e)
	{
		bool isModelValid = true;
		if (String.IsNullOrEmpty(nomeCompleto.Text) == false)
		{
			if (nomeCompleto.Text.Length < 3)
			{
				rfvNomeCompleto.IsValid = false;
				isModelValid = false;
			}
		}
		else
		{
			rfvNomeCompleto.IsValid = false;
			isModelValid = false;
		}

		//Validate CPF
		if (ValidatorCustom.IsCpf(cpf.Text) == false)
		{
			rfvCPF.IsValid = false;
			isModelValid = false;
		}

		//Validação server side
		if (isModelValid == false)
			return;

		string video = hdnFileName.Value + "." + hdnFileType.Value.ToLower();

		VisualizacaoVideoDAL.Instance().Inserir(video, cnpj.Text, cpf.Text, razaoSocial.Text, nomeCompleto.Text, System.Web.HttpContext.Current.Request.UserHostAddress);

		form1.Visible = false;

		Server.Transfer("VisualizacaoConteudo.aspx", true);
	}
}