﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class VisualizacaoConteudo : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!this.IsPostBack)
		{
			String userAgent = HttpContext.Current.Request.UserAgent;
			string baseURL = "";
			if (Request.Url.Host.Contains("expresso.bradesco"))
				baseURL = "expresso.bradesco";
			else
			{
				baseURL = "expresso.predcd.bradesco.com.br";
			}

			string fileType = Request.Form["hdnFileType"].ToLower();
			string fileName = Request.Form["hdnFileName"] + "." + fileType;
			string finalURL = "https" + Uri.SchemeDelimiter + baseURL + Request.Form["hdnPathFile"] + fileName;

			string flashplayer = "https" + Uri.SchemeDelimiter + baseURL + "/portal/layout/html5lightbox/html5boxplayer.swf";

			StringBuilder sb = new StringBuilder();
			if (fileType.Contains("htm"))
			{
				sb.Append("<script type=\"text/javascript\">");
				sb.AppendLine("setTimeout(function () { location.href = '" + @finalURL + "';}, 500);");
				sb.AppendLine("</script>");

				Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "OpenFile", sb.ToString());
			}
			else if (!ValidatorCustom.isVideo(fileType))
			{
				sb.Append("<script type=\"text/javascript\">");
				sb.AppendLine("window.open('" + @finalURL + "', '_blank');");
				sb.AppendLine("if (window.parent != null && window.parent != undefined)");
				sb.AppendLine("{");
				sb.AppendLine("window.parent.postMessage('" + @finalURL + "', '*');");
				sb.AppendLine("}");
				sb.AppendLine("</script>");

				Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "OpenFile", sb.ToString());
			}
			else
			{
				if (userAgent.Contains("MSIE") || Request.Browser.Type.Equals("InternetExplorer11"))
					sb.Append("<embed width=\"100%\" height=\"100%\" pluginspage=\"http://www.adobe.com/go/getflashplayer\" src=\"" + @flashplayer + "\" type=\"application/x-shockwave-flash\" wmode=\"transparent\" flashvars=\"width=800&amp;height=400&amp;jsobjectname=html5Lightbox&amp;hidecontrols=0&amp;hideplaybutton=0&amp;videofile=@finalURL&amp;hdfile=&amp;ishd=0&amp;defaultvolume=1&amp;autoplay=1&amp;loop=0&amp;errorcss=.html5box-errortext-align%3Acenter%3B%20color%3A%23ff0000%3B%20font-size%3A14px%3B%20font-family%3AArial%2C%20sans-serif%3B&amp;id=0\" allowscriptaccess=\"always\" allowfullscreen=\"true\" quality=\"high\">");
				else
					sb.Append("<video id=\"html5-lightbox-video\" width=\"100%\" height=\"100%\" autoplay=\"\" controls=\"controls\" src=\"" + @finalURL + "\"></video>");

				ltConteudo.Text = sb.ToString();
			}
		}
	}
}