﻿using Bradesco.Expresso.Entidades;
using Bradesco.Expresso.Negocios;
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Expresso.Validacao;
using System.Net.Mail;
using System.Configuration;

public partial class _Vantagens : System.Web.UI.Page
{
    //
    String messageError = "Desculpe, não foi possível enviar nesse momento. Tente mais tarde!";
    Vantagens Vantagens = new Vantagens();
    string uf = string.Empty;
    #region Eventos

    String ClassErro = "frm-erro-in";

    public EstadoNegocio EstadoNegocio
    {
        get
        {
            return new EstadoNegocio();
        }
    }

    public VantagensNegocio VantagensNegocio
    {
        get
        {
            return new VantagensNegocio();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ListarEstados();
            LimparCampos();
        }
    }

    protected void enviar_Click(object sender, EventArgs e)
    {
        lblResposta.Visible = false;

        if (Page.IsValid)
        {
            try
            {
                if (ValidarCampos())
                {
                    if (InserirVantagens())
                    {
                        pnl1.Visible = false;
                        pnl2.Visible = true;
                        LimparCampos();
                        msg_sucesso.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.Page.GetType(), "alert", "alert('" + ex.Message + "');", true);
            }
        }
    }

    protected void chkAceiteAdesao_CheckedChanged(object sender, EventArgs e)
    {
        chkAceiteSemAdesao.Checked = false;
    }

    protected void chkAceiteSemAdesao_CheckedChanged(object sender, EventArgs e)
    {
        chkAceiteAdesao.Checked = false;
    }

    #endregion

    #region Métodos

    /// <summary>
    /// Marcar Campos para Validação
    /// </summary>
    /// <param name="obj"></param>
    /// <param name="err"></param>
    public void MarcarCampo(object obj, bool err)
    {
        if (obj.GetType() == typeof(TextBox))
        {
            if (err)
                ((TextBox)obj).Style.Add("border", "1px solid red");
            else
                ((TextBox)obj).Style.Remove("border");
        }
        else if (obj.GetType() == typeof(DropDownList))
        {
            if (err)
                ((DropDownList)obj).Style.Add("border", "1px solid red");
            else
                ((DropDownList)obj).Style.Remove("border");
        }
        else if (obj.GetType() == typeof(CheckBox))
        {
            if (err)
                ((CheckBox)obj).Style.Add("border", "1px solid red");
            else
                ((CheckBox)obj).Style.Remove("border");
        }
    }

    /// <summary>
    /// Listar Estados
    /// </summary>
    private void ListarEstados()
    {
        ddlEstados.DataTextField = "Nome";
        ddlEstados.DataValueField = "UF";
        ddlEstados.DataSource = EstadoNegocio.EstadoSelectLst();
        ddlEstados.DataBind();
        ddlEstados.Items.Insert(0, new ListItem("Selecione um Estado", "-1"));
    }

    /// <summary>
    /// Validar os Campos
    /// </summary>
    /// <returns></returns>
    private Boolean ValidarCampos()
    {
        Validacao v = new Validacao();
        String CSSClassErro = ClassErro;
        Boolean erro = false;

        if (!chkAceiteAdesao.Checked && !chkAceiteSemAdesao.Checked)
        {
            msg_chkAceiteAdesao.Visible = erro = true;
            msg_chkAceiteSemAdesao.Visible = erro;
        }
        else
        {
            msg_chkAceiteAdesao.Visible = false;
            msg_chkAceiteSemAdesao.Visible = false;
        }


        if (!chkLiEAceiteTermoAdesao.Checked)
        {
            msg_chkLiEAceiteTermoAdesao.Visible = erro = true;
        }
        else
        {
            msg_chkLiEAceiteTermoAdesao.Visible = false;
        }



        if (String.IsNullOrEmpty(ipt_nome.Text))
        {
            msg_ipt_nome.Visible = erro = true;
            MarcarCampo(ipt_nome, true);
        }
        else
        {
            msg_ipt_nome.Visible = false;
            MarcarCampo(ipt_nome, false);
        }

        if (String.IsNullOrEmpty(ipt_agencia.Text))
        {
            msg_ipt_agencia.Visible = erro = true;
            MarcarCampo(ipt_agencia, true);
        }
        else
        {
            msg_ipt_agencia.Visible = false;
            MarcarCampo(ipt_agencia, false);
        }

        if (String.IsNullOrEmpty(ipt_conta.Text) || String.IsNullOrEmpty(ipt_conta2.Text))
        {
            msg_ipt_conta.Visible = erro = true;
            MarcarCampo(ipt_conta, true);
            MarcarCampo(ipt_conta2, true);
        }
        else
        {
            msg_ipt_conta.Visible = false;
            MarcarCampo(ipt_conta, false);
            MarcarCampo(ipt_conta2, false);
        }

        if (String.IsNullOrEmpty(ipt_razaoSocial.Text))
        {
            msg_ipt_razaoSocial.Visible = erro = true;
            MarcarCampo(ipt_razaoSocial, true);
        }
        else
        {
            msg_ipt_razaoSocial.Visible = false;
            MarcarCampo(ipt_razaoSocial, false);
        }

        if (String.IsNullOrEmpty(ipt_cnpj01.Text) || String.IsNullOrEmpty(ipt_cnpj02.Text) || String.IsNullOrEmpty(ipt_cnpj03.Text) || String.IsNullOrEmpty(ipt_cnpj04.Text) || String.IsNullOrEmpty(ipt_cnpj05.Text))
        {
            msg_ipt_cnpj01.Visible = erro = true;
            msg_ipt_cnpj01.Text = "O campo CNPJ obrigatório.";
            MarcarCampo(ipt_cnpj01, true);
            MarcarCampo(ipt_cnpj02, true);
            MarcarCampo(ipt_cnpj03, true);
            MarcarCampo(ipt_cnpj04, true);
            MarcarCampo(ipt_cnpj05, true);
        }
        else
        {
            msg_ipt_cnpj01.Visible = false;
            MarcarCampo(ipt_cnpj01, false);
            MarcarCampo(ipt_cnpj02, false);
            MarcarCampo(ipt_cnpj03, false);
            MarcarCampo(ipt_cnpj04, false);
            MarcarCampo(ipt_cnpj05, false);
        }


        if (ddlEstados.SelectedIndex == 0)
        {
            msg_estados.Visible = erro = true;
            MarcarCampo(ddlEstados, true);
        }
        else
        {
            msg_estados.Visible = false;
            MarcarCampo(ddlEstados, false);
        }

        if (String.IsNullOrEmpty(ipt_end.Text))
        {
            msg_ipt_end.Visible = erro = true;
            MarcarCampo(ipt_end, true);
        }
        else
        {
            msg_ipt_end.Visible = false;
            MarcarCampo(ipt_end, false);
        }

        if (String.IsNullOrEmpty(ipt_num.Text))
        {
            msg_ipt_num.Visible = erro = true;
            MarcarCampo(ipt_num, true);
        }
        else
        {
            msg_ipt_num.Visible = false;
            MarcarCampo(ipt_num, false);
        }

        if ((String.IsNullOrEmpty(ipt_cep01.Text) || String.IsNullOrEmpty(ipt_cep02.Text)) || (!v.validaNumCaracteres((ipt_cep01.Text.Length + ipt_cep02.Text.Length), 8, 9)))
        {
            msg_ipt_cep.Visible = erro = true;
            MarcarCampo(ipt_cep01, true);
            MarcarCampo(ipt_cep02, true);
        }
        else
        {
            msg_ipt_cep.Visible = false;
            MarcarCampo(ipt_cep01, false);
            MarcarCampo(ipt_cep02, false);
        }

        if (String.IsNullOrEmpty(ipt_bairro.Text))
        {
            msg_ipt_bairro.Visible = erro = true;
            MarcarCampo(ipt_bairro, true);
        }
        else
        {
            msg_ipt_bairro.Visible = false;
            MarcarCampo(ipt_bairro, false);
        }

        if (String.IsNullOrEmpty(ipt_cidade.Text))
        {
            msg_ipt_cidade.Visible = erro = true;
            MarcarCampo(ipt_cidade, true);
        }
        else
        {
            msg_ipt_cidade.Visible = false;
            MarcarCampo(ipt_cidade, false);
        }

        if ((String.IsNullOrEmpty(ipt_telefone01.Text) || String.IsNullOrEmpty(ipt_telefone02.Text)) || (v.validaNumCaracteres(ipt_telefone01.Text.Length + ipt_telefone02.Text.Length, 8, 9)))
        {
            msg_ipt_telefone.Visible = erro = true;
            MarcarCampo(ipt_telefone01, true);
            MarcarCampo(ipt_telefone02, true);
        }
        else
        {
            msg_ipt_telefone.Visible = false;
            MarcarCampo(ipt_telefone01, false);
            MarcarCampo(ipt_telefone02, false);
        }

        if (String.IsNullOrEmpty(ipt_mail.Text))
        {
            msg_ipt_mail.Visible = erro = true;
            MarcarCampo(ipt_mail, true);
        }
        else
        {
            if (v.ValidaEmailRet(ipt_mail))
            {
                msg_ipt_mail.Visible = false;
                MarcarCampo(ipt_mail, false);
            }
            else
            {
                msg_ipt_mail.Visible = erro = true;
                msg_ipt_mail.Text = "E-mail inválido! Por favor, informe um e-mail válido.";
                MarcarCampo(ipt_mail, true);
            }
        }

        return !erro;
    }

    /// <summary>
    /// Limpar Os Campos
    /// </summary>
    private void LimparCampos()
    {
        ipt_razaoSocial.Text = "";
        ipt_num.Text = "";
        ipt_bairro.Text = "";
        ipt_cidade.Text = "";
        ipt_cnpj01.Text = "";
        ipt_cnpj02.Text = "";
        ipt_cnpj03.Text = "";
        ipt_cnpj04.Text = "";
        ipt_cnpj05.Text = "";
        ipt_cep01.Text = "";
        ipt_cep02.Text = "";
        ipt_end.Text = "";
        ipt_nome.Text = "";
        ipt_mail.Text = "";
        ipt_telefone01.Text = "";
        ipt_telefone02.Text = "";
        ddlEstados.SelectedIndex = 0;
        ipt_agencia.Text = "";
        ipt_conta.Text = "";
        ipt_conta2.Text = "";

        msg_chkAceiteAdesao.Visible = false;
        msg_chkAceiteSemAdesao.Visible = false;
        msg_chkLiEAceiteTermoAdesao.Visible = false;
        msg_estados.Visible = false;
        msg_ipt_agencia.Visible = false;
        msg_ipt_bairro.Visible = false;
        msg_ipt_cep.Visible = false;
        msg_ipt_cidade.Visible = false;
        msg_ipt_cnpj01.Visible = false;
        msg_ipt_conta.Visible = false;
        msg_ipt_end.Visible = false;
        msg_ipt_mail.Visible = false;
        msg_ipt_nome.Visible = false;
        msg_ipt_num.Visible = false;
        msg_ipt_razaoSocial.Visible = false;
        msg_ipt_telefone.Visible = false;

    }

    private bool InserirVantagens()
    {
        try
        {
            Validacao v = new Validacao();

            if (ddlEstados.SelectedIndex > -1)
                uf = ddlEstados.SelectedItem.Value;

            Vantagens.AdesaoSeguro = chkAceiteAdesao.Checked;
            Vantagens.AceiteRegulamento = chkLiEAceiteTermoAdesao.Checked;

            Vantagens.DadosEmpresa = new DadosEmpresaVantagens
            {
                RazaoSocial = v.Injection(ipt_razaoSocial.Text),
                Bairro = v.Injection(ipt_bairro.Text),
                Numero = v.Injection(ipt_num.Text),
                Cidade = v.Injection(ipt_cidade.Text),
                Cnpj = v.Injection(ipt_cnpj01.Text + ipt_cnpj02.Text + ipt_cnpj03.Text + ipt_cnpj04.Text + ipt_cnpj05.Text),
                Endereco = v.Injection(ipt_end.Text)
            };
            Vantagens.DadosContato = new DadosContatoVantagens
            {
                Nome = v.Injection(ipt_nome.Text),
                Email = v.Injection(ipt_mail.Text),
                TelefoneDDD = v.Injection(ipt_telefone01.Text),
                TelefoneNumero = v.Injection(ipt_telefone02.Text),
                Agencia = v.Injection(ipt_agencia.Text),
                ContaCorrente = v.Injection(ipt_conta.Text + ipt_conta2.Text)
            };

            var retorno = VantagensNegocio.Inserir(Vantagens, null);

            if (retorno)
            {
                EnviarEmail();
                return true;
            }
            else
                return false;

        }
        catch (Exception)
        {
            throw;
        }

    }

    private void EnviarEmail()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("<HTML>");
        sb.AppendLine("<HEAD></HEAD>");
        sb.AppendLine("<BODY>");
        if (chkAceiteAdesao.Checked)
            sb.AppendLine("<center><b style='color:#000;'>Adesão ao clube de vantagens (benefícios completo)</b></center>");
        else
            sb.AppendLine("<center><b style='color:#000;'>Adesão ao clube de vantagens (benefícios incompleto)</b></center>");
        sb.AppendLine("<br>");
        sb.AppendLine("Vocês estão recebendo os dados de um cliente que preencheu no site Bradesco Expresso o formulário Clube de Vantagens, ");
        if (chkAceiteAdesao.Checked)
        {
            sb.AppendLine("no qual afirma possuir interesse em fazer parte do Clube de Vantagens Bradesco Expresso e <b style='color:#000;'>está de acordo em aderir a todos os benefícios do clube.</b>");
            sb.AppendLine("<br><br>");
            sb.AppendLine("<b style='color:#000'>- Pilar financeiro</b> (créditos em conta e seguro do numerário)");
        }
        else
        {
            sb.AppendLine("no qual afirma possuir interesse em fazer parte do Clube de Vantagens Bradesco Expresso, <b style='color:#000;'>mas não está de acordo em aderir a todos os benefícios do clube (não optante pelo seguro do numerário).</b>");
            sb.AppendLine("<br><br>");
            sb.AppendLine("<b style='color:#000'>- Pilar financeiro</b> (créditos em conta)");
        }
        sb.AppendLine("<br><br>");
        sb.AppendLine("<b style='color:#000'>- Pilar relacionamento</b> (produtos e serviços com condições especiais, taxas diferenciadas e tarifas reduzidas, entre outros).");
        sb.AppendLine("<br><br>");
        sb.AppendLine("Seguem os dados cadastrais para que vocês possam entrar em contato e alavancar os negócios:");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Dados da empresa</b> ");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Razão social: </b> " + Vantagens.DadosEmpresa.RazaoSocial);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Cnpj: </b> " + Vantagens.DadosEmpresa.Cnpj);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Endereço: </b> " + Vantagens.DadosEmpresa.Endereco);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Número: </b> " + Vantagens.DadosEmpresa.Numero);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Bairro: </b> " + Vantagens.DadosEmpresa.Bairro);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Cidade: </b> " + Vantagens.DadosEmpresa.Cidade);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Estado: </b> " + uf);
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Dados do contato</b> ");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Nome: </b> " + Vantagens.DadosContato.Nome);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>E-mail: </b> " + Vantagens.DadosContato.Email);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Telefone: </b> " + Vantagens.DadosContato.TelefoneDDD + " " + Vantagens.DadosContato.TelefoneNumero);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Agência: </b> " + Vantagens.DadosContato.Agencia);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>Conta-Corrente: </b> " + Vantagens.DadosContato.ContaCorrente);
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("</BODY>");
        sb.AppendLine("</HTML>");

        using (MailMessage email = new MailMessage())
        {
            try
            {
                email.From = new MailAddress("clubedevantagens@bradesco.com.br");
                email.Subject = "PREENCHIMENTO FORMULÁRIO  - Clube de Vantagens Bradesco Expresso";
                email.Body = sb.ToString();
                email.IsBodyHtml = true;
                email.To.Add("clubeexpresso@bradesco.com.br");

                SmtpClient ClienteSMTP = new SmtpClient(ConfigurationManager.AppSettings["SMTP.Host"].ToString(), 25);
                ClienteSMTP.UseDefaultCredentials = false;
                ClienteSMTP.EnableSsl = false;
                ClienteSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;

                ClienteSMTP.Send(email);
            }
            catch (SmtpException ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alerta", "<script>alert('E-mail clube de vantagens não enviado. " + ex.Message + " Tente novamente mais tarde.')</script>", false);
                throw new Exception(ex.Message);
            }
        }

    }

    #endregion
}