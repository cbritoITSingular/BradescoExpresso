﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Email_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        EnviarEmail();
    }

    private bool EnviarEmail()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("<HTML>");
        sb.AppendLine("<HEAD></HEAD>");
        sb.AppendLine("<BODY>");
        sb.AppendLine("<p>Prezado Gerente,</p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>O cliente abaixo se cadastrou no site Bradesco Expresso manifestando interesse em ser Correspondente em sua região, desta forma, solicitamos que realize o contato <b style='color:#000'>imediatamente</b> agendando a visita para identificar a possibilidade de contratação conforme orientações na CO Contratação do Bradesco Expresso vigente.</p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>Não se esqueça de preencher todas as tratativas no <b style='color:#000'>painel de controle</b> <a href='https://bancobradesco.sharepoint.com/sites/BradescoExpresso-SejaumCorrespondente/Lists/Acompanhamento/AllItems.aspx?OR=Teams%2DHL&CT=1660049349608&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA3MDMwMDgxNCIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D'>Seja um Correspondente - Acompanhamento - Cliente</a></p>");
        sb.AppendLine("<br>");

        sb.AppendLine("<b style='color:#000'>DADOS DA EMPRESA</b>");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>RAZÃO SOCIAL: </b> " + "Teste Razão Social");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>RAMO DE ATIVIDADE: </b> " + "Teste Ramo de Atividade");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CNPJ: </b> " + "24.267.475/0001-07");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CEP: </b> " + "06036-080");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>ESTADO: </b> " + "SP");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CIDADE: </b> " + "Osasco");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>BAIRRO: </b> " + "Centro");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>ENDEREÇO: </b> " + "Avenida Bussocaba");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>NÚMERO: </b> " + "100");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>DADOS DO CONTATO</b>");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>NOME: </b> " + "Teste Nome");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>E-MAIL: </b> " + "email@gmail.com");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>TELEFONE: </b> " + "(11) 98877-6655");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CLIENTE CORRENTISTA?: </b> " + "SIM");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>AGÊNCIA: </b> " + "2856" + " - " + "Matriz");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CONTA: </b> " + "1463669-2");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>AGÊNCIA MAIS PRÓXIMA DA EMPRESA: </b> " + "2856" + " - " + "Matriz");
        sb.AppendLine("<br>");        
        sb.AppendLine("<b style='color:#000'>OBSERVAÇÃO: </b> " + "Teste Observação");
        sb.AppendLine("<br>");        
        sb.AppendLine("<p>Qualquer dúvida estamos à disposição.</p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>Classificação: <strong>INTERNA</strong> \"Este documento foi classificado pelo Departamento Bradesco Varejo/Bradesco Expresso/PA - Área Bradesco Expresso e o acesso está autorizado, exclusivamente, aos destinatários contidos nesta mensagem\".</p>");
        sb.AppendLine("<br>");

        sb.AppendLine("</BODY>");
        sb.AppendLine("</HTML>");

        using (MailMessage email = new MailMessage())
        {
            try
            {
                email.From = new MailAddress("bradesco@infobradesco.com.br");
                email.Subject = "PREENCHIMENTO DO FORMULÁRIO - SEJA UM CORRESPONDENTE";
                email.Body = sb.ToString();
                email.IsBodyHtml = true;                
                email.To.Add("fabianoc.fernandes@bradesco.com.br");
                email.To.Add("alexandre.a.siqueira@bradesco.com.br");
                
                SmtpClient ClienteSMTP = new SmtpClient(ConfigurationManager.AppSettings["SMTP.Host"].ToString(), 25);
                ClienteSMTP.UseDefaultCredentials = false;
                ClienteSMTP.EnableSsl = false;
                ClienteSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;

                ClienteSMTP.Send(email);
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}