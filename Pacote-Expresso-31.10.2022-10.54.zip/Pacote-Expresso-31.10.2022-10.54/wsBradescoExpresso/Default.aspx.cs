﻿using Bradesco.Expresso.Entidades;
using Bradesco.Expresso.Negocios;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using Expresso.Validacao;
using System.Data;
using System.Net.Mail;
using System.Configuration;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Web;

public partial class _Default : System.Web.UI.Page, ICallbackEventHandler
{
    String ClassErro = "frm-erro-in";
    String messageError = "Desculpe, não foi possível enviar nesse momento. Tente mais tarde!";
    private string _strcallback = string.Empty;
    private string uf = "";
    private string ramos = "";
    private string origem = "";
    private string cnpjGetMember = "";
    private string agenciaNaoCorrentista = "";
    private string nomeAgenciaNaoCorrentista = "";
    private string agenciaProximaEmpresa = "";
    private string nomeAgenciaProximaEmpresa = "";
    AgenciaNegocio _agenciaNegocio = new AgenciaNegocio();

    #region Eventos
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ListarEstados();
            ListarRamos();
            ListarOrigem();
            LimparCampos();
        }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        string strfunctionAgencia = this.ClientScript.GetCallbackEventReference(this, "arg", "onSuceed", "context", "onError", true);
        string cbScriptAgencia = "function BuscaAgencia(arg,context){" + strfunctionAgencia + ";" + "}";

        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "BuscaAgencia", cbScriptAgencia, true);
        txtCEPBusca2.Attributes.Add("onblur", "BuscaAgencia(document.getElementById('txtCEPBusca').value + this.value + 'p2', document.getElementById('txtCEPBusca').value + this.value);");


        string strfunctionCEP = this.ClientScript.GetCallbackEventReference(this, "arg", "buscarCepCallback", "context", "onError", true);
        string cbScriptCEP = "function BuscarCEP(arg,context){" + strfunctionCEP + ";" + "}";

        Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "BuscarCEP", cbScriptCEP, true);
        ipt_cep02.Attributes.Add("onblur", "BuscarCEP(document.getElementById('ipt_cep01').value + this.value + 'p1', document.getElementById('ipt_cep01').value + this.value);");
    }

    public string GetCallbackResult()
    {
        if (!string.IsNullOrEmpty(_strcallback))
        {
            if (_strcallback.EndsWith("p1"))
                return ObterEndereco();
        }

        return string.Empty;
    }

    public void RaiseCallbackEvent(string eventArgument)
    {
        _strcallback = eventArgument;
    }

    protected void avancar_Click(object sender, EventArgs e)
    {
        lblResposta.Visible = false;

        if (Page.IsValid)
        {
            try
            {
                if (ValidarCampos(1))
                {
                    pn1.Visible = false;
                    pn2.Visible = true;
                    pn3.Visible = false;
                }
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.Page.GetType(), "alert", "alert('" + messageError + "');", true);
            }
        }
    }

    protected void voltar_Click(object sender, EventArgs e)
    {
        var messageError = string.Empty;
        if (Page.IsValid)
        {
            try
            {
                pn1.Visible = true;
                pn2.Visible = false;
                pn3.Visible = false;
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.Page.GetType(), "alert", "alert('" + messageError + "');", true);
            }
        }
    }

    protected void btnEnviarDados_Click(object sender, EventArgs e)
    {
        lblResposta.Visible = false;
        if (CaptchaForm.IsValid == true)
        {
            if (Page.IsValid)
            {
                if (ValidarCampos(2))
                {
                    if (InserirCorrespondente())
                    {
                        pn1.Visible = false;
                        pn2.Visible = false;
                        pn3.Visible = true;
                        LimparCampos();
                        msg_sucesso.Focus();
                    }
                }
            }
        }
    }

    #endregion

    #region Métodos
    public CorrespondenteNegocio CorrespodenteNegocio
    {
        get
        {
            return new CorrespondenteNegocio();
        }
    }
    
    public EstadoNegocio EstadoNegocio
    {
        get
        {
            return new EstadoNegocio();
        }
    }

    public RamoNegocio RamoNegocio
    {
        get
        {
            return new RamoNegocio();
        }
    }

    public EmailNegocio EmailNegocio
    {
        get
        {
            return new EmailNegocio();
        }
    }

    public OrigemNegocio OrigemNegocio
    {
        get
        {
            return new OrigemNegocio();
        }
    }
    
    public void MarcarCampo(object obj, bool err)
    {
        if (obj.GetType() == typeof(TextBox))
        {
            if (err)
                ((TextBox)obj).Style.Add("border", "1px solid red");
            else
                ((TextBox)obj).Style.Remove("border");
        }
        else if (obj.GetType() == typeof(DropDownList))
        {
            if (err)
                ((DropDownList)obj).Style.Add("border", "1px solid red");
            else
                ((DropDownList)obj).Style.Remove("border");
        }
    }
    
    private Boolean ValidarCampos(int step)
    {
        Validacao v = new Validacao();
        String CSSClassErro = ClassErro;
        Boolean erro = false;

        #region Step 1
        if (step == 1)
        {
            if (String.IsNullOrEmpty(ipt_razaoSocial.Text))
            {
                msg_ipt_razaoSocial.Visible = erro = true;
                MarcarCampo(ipt_razaoSocial, true);
            }
            else
            {
                msg_ipt_razaoSocial.Visible = false;
                MarcarCampo(ipt_razaoSocial, false);
            }

            if (ddlRamos.SelectedIndex == 0)
            {
                msg_ramos.Visible = erro = true;
                MarcarCampo(ddlRamos, true);
            }
            else
            {
                msg_ramos.Visible = false;
                MarcarCampo(ddlRamos, false);
            }

            if (ddlEstados.SelectedIndex == 0)
            {
                msg_estados.Visible = erro = true;
                MarcarCampo(ddlEstados, true);
            }
            else
            {
                msg_estados.Visible = false;
                MarcarCampo(ddlEstados, false);
            }

            if (String.IsNullOrEmpty(ipt_cnpj01.Text) || String.IsNullOrEmpty(ipt_cnpj02.Text) || String.IsNullOrEmpty(ipt_cnpj03.Text) || String.IsNullOrEmpty(ipt_cnpj04.Text) || String.IsNullOrEmpty(ipt_cnpj05.Text))
            {
                msg_ipt_cnpj01.Visible = erro = true;
                msg_ipt_cnpj01.Text = "O campo CNPJ obrigatório.";
                MarcarCampo(ipt_cnpj01, true);
                MarcarCampo(ipt_cnpj02, true);
                MarcarCampo(ipt_cnpj03, true);
                MarcarCampo(ipt_cnpj04, true);
                MarcarCampo(ipt_cnpj05, true);
            }
            else if ((!v.ValidaCNPJ(ipt_cnpj01.Text + ipt_cnpj02.Text + ipt_cnpj03.Text + ipt_cnpj04.Text + ipt_cnpj05.Text)))
            {
                msg_ipt_cnpj01.Visible = erro = true;
                msg_ipt_cnpj01.Text = "CNPJ inválido! Por favor, informe um CNPJ válido.";
                MarcarCampo(ipt_cnpj01, true);
                MarcarCampo(ipt_cnpj02, true);
                MarcarCampo(ipt_cnpj03, true);
                MarcarCampo(ipt_cnpj04, true);
                MarcarCampo(ipt_cnpj05, true);
            }
            else
            {
                msg_ipt_cnpj01.Visible = false;
                MarcarCampo(ipt_cnpj01, false);
                MarcarCampo(ipt_cnpj02, false);
                MarcarCampo(ipt_cnpj03, false);
                MarcarCampo(ipt_cnpj04, false);
                MarcarCampo(ipt_cnpj05, false);
            }

            if ((String.IsNullOrEmpty(ipt_cep01.Text) || String.IsNullOrEmpty(ipt_cep02.Text)) || (!v.validaNumCaracteres((ipt_cep01.Text.Length + ipt_cep02.Text.Length), 8, 9)))
            {
                msg_ipt_cep.Visible = erro = true;
                MarcarCampo(ipt_cep01, true);
                MarcarCampo(ipt_cep02, true);
            }
            else
            {
                msg_ipt_cep.Visible = false;
                MarcarCampo(ipt_cep01, false);
                MarcarCampo(ipt_cep02, false);
            }

            var retornoObterAgencia = ObterAgencia(step);
            if (retornoObterAgencia != "Ok")
            {
                msg_ipt_cep.Visible = erro = true;
                msg_ipt_cep.Text = retornoObterAgencia;
                MarcarCampo(ipt_cep01, true);
                MarcarCampo(ipt_cep02, true);
            }

            if (String.IsNullOrEmpty(ipt_end.Text))
            {
                msg_ipt_end.Visible = erro = true;
                MarcarCampo(ipt_end, true);
            }
            else
            {
                msg_ipt_end.Visible = false;
                MarcarCampo(ipt_end, false);
            }

            if (String.IsNullOrEmpty(ipt_cidade.Text))
            {
                msg_ipt_cidade.Visible = erro = true;
                MarcarCampo(ipt_cidade, true);
            }
            else
            {
                msg_ipt_cidade.Visible = false;
                MarcarCampo(ipt_cidade, false);
            }

            if (String.IsNullOrEmpty(ipt_bairro.Text))
            {
                msg_ipt_bairro.Visible = erro = true;
                MarcarCampo(ipt_bairro, true);
            }
            else
            {
                msg_ipt_bairro.Visible = false;
                MarcarCampo(ipt_bairro, false);
            }

            if (String.IsNullOrEmpty(ipt_num.Text))
            {
                msg_ipt_num.Visible = erro = true;
                MarcarCampo(ipt_num, true);
            }
            else
            {
                msg_ipt_num.Visible = false;
                MarcarCampo(ipt_num, false);
            }

            if (ddlOrigem.SelectedIndex == 0)
            {
                msg_origem.Visible = erro = true;
                MarcarCampo(ddlOrigem, true);
            }
            else
            {
                msg_origem.Visible = false;
                MarcarCampo(ddlOrigem, false);
            }

            if (ddlOrigem.SelectedValue == "6") //Member Get Member
            {
                if (String.IsNullOrEmpty(ipt_cnpj_member01.Text) || String.IsNullOrEmpty(ipt_cnpj_member02.Text) || String.IsNullOrEmpty(ipt_cnpj_member03.Text) || String.IsNullOrEmpty(ipt_cnpj_member04.Text) || String.IsNullOrEmpty(ipt_cnpj_member05.Text))
                {
                    msg_ipt_cnpj_member01.Visible = erro = true;
                    msg_ipt_cnpj_member01.Text = "O campo CNPJ Indicante é obrigatório.";
                    MarcarCampo(ipt_cnpj_member01, true);
                    MarcarCampo(ipt_cnpj_member02, true);
                    MarcarCampo(ipt_cnpj_member03, true);
                    MarcarCampo(ipt_cnpj_member04, true);
                    MarcarCampo(ipt_cnpj_member05, true);
                }
                else if ((!v.ValidaCNPJ(ipt_cnpj_member01.Text + ipt_cnpj_member02.Text + ipt_cnpj_member03.Text + ipt_cnpj_member04.Text + ipt_cnpj_member05.Text)))
                {
                    msg_ipt_cnpj_member01.Visible = erro = true;
                    msg_ipt_cnpj_member01.Text = "CNPJ inválido! Por favor, informe um CNPJ válido.";
                    MarcarCampo(ipt_cnpj_member01, true);
                    MarcarCampo(ipt_cnpj_member02, true);
                    MarcarCampo(ipt_cnpj_member03, true);
                    MarcarCampo(ipt_cnpj_member04, true);
                    MarcarCampo(ipt_cnpj_member05, true);

                    ipt_cnpj_member01.Text = "";
                    ipt_cnpj_member02.Text = "";
                    ipt_cnpj_member03.Text = "";
                    ipt_cnpj_member04.Text = "";
                    ipt_cnpj_member05.Text = "";
                }
            }
        }
        #endregion
        #region Step 2
        else if (step == 2)
        {
            if (String.IsNullOrEmpty(ipt_nome.Text))
            {
                msg_ipt_nome.Visible = erro = true;
                MarcarCampo(ipt_nome, true);
            }
            else
            {
                msg_ipt_nome.Visible = false;
                MarcarCampo(ipt_nome, false);
            }

            if (String.IsNullOrEmpty(ipt_mail.Text))
            {
                msg_ipt_mail.Visible = erro = true;
                MarcarCampo(ipt_mail, true);
            }
            else
            {
                if (v.ValidaEmailRet(ipt_mail))
                {
                    msg_ipt_mail.Visible = false;
                    MarcarCampo(ipt_mail, false);
                }
                else
                {
                    msg_ipt_mail.Visible = erro = true;
                    msg_ipt_mail.Text = "E-mail inválido! Por favor, informe um e-mail válido.";
                    MarcarCampo(ipt_mail, true);
                }

            }

            if (rdoCorrentistaSim.Checked)
            {
                MarcarCampo(txtCEPBusca, false);
                MarcarCampo(txtCEPBusca2, false);
                msg_txtCEPBusca.Visible = erro = false;

                pnContaCorrente.Attributes.CssStyle.Add("display", "block");
                pnCep.Attributes.CssStyle.Add("display", "none");

                if (String.IsNullOrEmpty(txtAgencia.Text))
                {
                    msg_txtAgencia.Visible = erro = true;
                    MarcarCampo(txtAgencia, true);
                }
                else
                {
                    msg_txtAgencia.Visible = false;
                    MarcarCampo(txtAgencia, false);
                }

                if (String.IsNullOrEmpty(txtConta.Text) || String.IsNullOrEmpty(txtDigitoConta.Text))
                {
                    msg_txtConta.Visible = erro = true;
                    MarcarCampo(txtConta, true);
                    MarcarCampo(txtDigitoConta, true);
                }
                else
                {
                    msg_txtConta.Visible = false;
                    MarcarCampo(txtConta, false);
                    MarcarCampo(txtDigitoConta, false);
                }
            }

            if (rdoCorrentistaNao.Checked)
            {
                MarcarCampo(txtAgencia, false);
                MarcarCampo(txtConta, false);
                MarcarCampo(txtDigitoConta, false);
                msg_txtAgencia.Visible = false;
                msg_txtConta.Visible = erro = false;

                pnContaCorrente.Attributes.CssStyle.Add("display", "none");
                
                if (String.IsNullOrEmpty(txtCEPBusca.Text) || String.IsNullOrEmpty(txtCEPBusca2.Text))
                {
                    msg_txtCEPBusca.Visible = erro = true;
                    MarcarCampo(txtCEPBusca, true);
                    MarcarCampo(txtCEPBusca2, true);
                }
                else
                {
                    msg_txtCEPBusca.Visible = false;
                    MarcarCampo(txtCEPBusca, false);
                    MarcarCampo(txtCEPBusca2, false);
                }

                var retornoObterAgencia = ObterAgencia(step);
                if (retornoObterAgencia != "Ok")
                {
                    msg_txtCEPBusca.Visible = erro = true;
                    msg_txtCEPBusca.Text = retornoObterAgencia;
                    MarcarCampo(txtCEPBusca, true);
                    MarcarCampo(txtCEPBusca2, true);
                }

            }

            if ((String.IsNullOrEmpty(ipt_telefone01.Text) || String.IsNullOrEmpty(ipt_telefone02.Text)) || (v.validaNumCaracteres(ipt_telefone01.Text.Length + ipt_telefone02.Text.Length, 8, 9)))
            {
                msg_ipt_telefone.Visible = erro = true;
                MarcarCampo(ipt_telefone01, true);
                MarcarCampo(ipt_telefone02, true);
            }
            else
            {
                msg_ipt_telefone.Visible = false;
                MarcarCampo(ipt_telefone01, false);
                MarcarCampo(ipt_telefone02, false);
            }
        }
        else
            return false;

        #endregion

        return !erro;
    }
    
    private void LimparCampos()
    {
        ipt_razaoSocial.Text = "";
        ddlRamos.SelectedIndex = 0;
        ddlOrigem.SelectedIndex = 0;
        ipt_num.Text = "";
        ipt_cidade.Text = "";
        ipt_bairro.Text = "";
        ipt_cnpj01.Text = "";
        ipt_cnpj02.Text = "";
        ipt_cnpj03.Text = "";
        ipt_cnpj04.Text = "";
        ipt_cnpj05.Text = "";
        ipt_cep01.Text = "";
        ipt_cep02.Text = "";
        ipt_end.Text = "";
        ipt_nome.Text = "";
        ipt_mail.Text = "";
        ipt_telefone01.Text = "";
        ipt_telefone02.Text = "";
        txtCEPBusca.Text = "";
        txtAgencia.Text = "";
        txtDigitoConta.Text = "";
        ddlEstados.SelectedIndex = 0;
        rdoCorrentistaNao.Checked = true;
        ipt_cnpj_member01.Text = "";
        ipt_cnpj_member02.Text = "";
        ipt_cnpj_member03.Text = "";
        ipt_cnpj_member04.Text = "";
        ipt_cnpj_member05.Text = "";

        msg_estados.Visible = false;
        msg_ipt_cep.Visible = false;
        msg_ipt_cidade.Visible = false;
        msg_ipt_bairro.Visible = false;
        msg_ipt_cnpj01.Visible = false;
        msg_ipt_end.Visible = false;
        msg_ipt_mail.Visible = false;
        msg_ipt_nome.Visible = false;
        msg_ipt_num.Visible = false;
        msg_ipt_razaoSocial.Visible = false;
        msg_ramos.Visible = false;
        msg_origem.Visible = false;
        msg_ipt_telefone.Visible = false;
        msg_rdo_correntista.Visible = false;
        msg_txtCEPBusca.Visible = false;
        msg_txtConta.Visible = false;
        msg_txtAgencia.Visible = false;
        txtObs.Text = "";
        msg_ipt_cnpj_member01.Visible = false;
    }
    
    private bool InserirCorrespondente()
    {
        Correspondente correspondente = new Correspondente();
        Validacao v = new Validacao();

        var agencia = string.Empty;
        var conta = string.Empty;
        int digitoConta = 0;
        var nomeAgencia = string.Empty;        

        try
        {
            if (rdoCorrentistaSim.Checked)
            {
                agencia = txtAgencia.Text;
                conta = txtConta.Text;
                digitoConta = int.Parse(txtDigitoConta.Text);

                if (HttpContext.Current.Request.IsSecureConnection)
                    ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(this.CertificateValidationCallBack);

                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                BuscaAgenciasPorCEP.RededeAtendimento buscaagenciasporcep = new BuscaAgenciasPorCEP.RededeAtendimento();
                var pnt = buscaagenciasporcep.CarregaAgenciaPorCodigo(Convert.ToInt32(agencia), null);

                if (pnt.Nome == null)
                {
                    msg_txtAgencia.Visible = true;
                    if (agencia == string.Empty)
                    {
                        msg_txtAgencia.Text = "Informe uma agência válida.";
                    }
                    else
                    {
                        msg_txtAgencia.Text = "Agência não encontrada.";
                    }
                    MarcarCampo(txtAgencia, true);
                    return false;
                }
                nomeAgencia = pnt.Nome.Trim();

                if (conta == string.Empty || txtDigitoConta.Text == string.Empty)
                {
                    msg_txtConta.Text = "Informe uma conta e digíto válida.";
                    MarcarCampo(txtConta, true);
                    MarcarCampo(txtDigitoConta, true);
                    return false;
                }

                if (!ValidaDigitoConta(conta, digitoConta))
                {
                    msg_txtConta.Visible = true;
                    msg_txtConta.Text = "Verifique conta e dígito.";
                    MarcarCampo(txtConta, true);
                    MarcarCampo(txtDigitoConta, true);
                    return false;
                }
            }
            else if (rdoCorrentistaNao.Checked)
            {
                agencia = agenciaNaoCorrentista;
                nomeAgencia = nomeAgenciaNaoCorrentista;
                conta = "Não definida";
            }

            string[] estados = new string[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "RS", "SC", "SE", "SP", "TO" };
            if (!string.IsNullOrEmpty(ddlEstados.SelectedValue) && estados.Contains(ddlEstados.SelectedValue))
                uf = ddlEstados.SelectedValue;

            if (ddlRamos.SelectedIndex > -1)
                ramos = ddlRamos.SelectedItem.Text;

            if (ddlOrigem.SelectedIndex > -1)
            {
                origem = ddlOrigem.SelectedItem.Text;
                cnpjGetMember = (ipt_cnpj_member01.Text + ipt_cnpj_member02.Text + ipt_cnpj_member03.Text + ipt_cnpj_member04.Text + ipt_cnpj_member05.Text);
            }

            correspondente.DadosEmpresa = new DadosEmpresa
            {
                RazaoSocial = v.Injection(ipt_razaoSocial.Text),
                RamoAtividade = v.Injection(ramos),
                Numero = v.Injection(ipt_num.Text),
                Cidade = v.Injection(ipt_cidade.Text),
                Estado = v.Injection(uf),
                Bairro = v.Injection(ipt_bairro.Text),
                Cnpj = v.Injection(ipt_cnpj01.Text + ipt_cnpj02.Text + ipt_cnpj03.Text + ipt_cnpj04.Text + ipt_cnpj05.Text),
                Cep = v.Injection(ipt_cep01.Text + ipt_cep02.Text),
                Endereco = v.Injection(ipt_end.Text),
                Origem = v.Injection(origem),
                CnpjGetMember = v.Injection(cnpjGetMember)
            };

            correspondente.DadosContato = new DadosContato
            {
                Nome = v.Injection(ipt_nome.Text),
                Email = v.Injection(ipt_mail.Text),
                TelefoneNumero = v.Injection(ipt_telefone01.Text + ipt_telefone02.Text.Replace("-", "")),
                Correntista = rdoCorrentistaSim.Checked ? 1 : 0,
                Observacao = v.Injection(txtObs.Text),
                Agencia = v.Injection(agencia),
                Conta = v.Injection(conta),
                NomeAgencia = v.Injection(nomeAgencia),
                AgenciaProxima = v.Injection(Session["agenciaProximaEmpresa"].ToString()),
                NomeAgenciaProxima = v.Injection(Session["nomeAgenciaProximaEmpresa"].ToString())
            };

            bool retorno = CorrespodenteNegocio.Inserir(correspondente, null);

            if (retorno)
            {
                //Evitar erro de envio de email na Pré.
                try
                {
                    retorno = EnviaEmailProspeccao(correspondente);
                    retorno = EnviaEmailCliente(correspondente);
                }
                catch (Exception ex)
                {
                }
            }

            return retorno;
        }

        catch (Exception)
        {
            throw;
        }

    }

    public bool CertificateValidationCallBack(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErros)
    {
        return true;
    }

    private bool EnviaEmailCliente(Correspondente correspondente)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("<HTML>");
        sb.AppendLine("<HEAD></HEAD>");
        sb.AppendLine("<BODY>");
        sb.AppendLine("<p>Olá  <b style='color:#000'>" + correspondente.DadosContato.Nome + "</b></p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>Ficamos muito felizes por seu interesse em ser nosso parceiro.</p>");
        sb.AppendLine("<br>");        
        sb.AppendLine("<p>Em breve, um de nossos consultores entrará em contato com você.</ p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>Equipe Bradesco Expresso</ p>");
        sb.AppendLine("</BODY>");
        sb.AppendLine("</HTML>");

        using (MailMessage email = new MailMessage())
        {
            try
            {
                email.From = new MailAddress("bradesco@infobradesco.com.br");
                email.Subject = "PREENCHIMENTO DO FORMULÁRIO - SEJA UM CORRESPONDENTE";
                email.Body = sb.ToString();
                email.IsBodyHtml = true;
                email.To.Add(correspondente.DadosContato.Email);

                SmtpClient ClienteSMTP = new SmtpClient(ConfigurationManager.AppSettings["SMTP.Host"].ToString(), 25);
                ClienteSMTP.UseDefaultCredentials = false;
                ClienteSMTP.Send(email);
                return true;
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alerta", "<script>alert('E-mail do cliente não enviado. " + ex.Message + " Tente novamente mais tarde.')</script>", false);
                return false;
            }
        }
    }
    private bool EnviaEmailProspeccao(Correspondente correspondente)
    {

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("<HTML>");
        sb.AppendLine("<HEAD></HEAD>");
        sb.AppendLine("<BODY>");
        sb.AppendLine("<p>Prezado Gerente,</p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>O cliente abaixo se cadastrou no site Bradesco Expresso manifestando interesse em ser Correspondente em sua região, desta forma, solicitamos que realize o contato <b style='color:#000'>imediatamente</b> agendando a visita para identificar a possibilidade de contratação conforme orientações na CO Contratação do Bradesco Expresso vigente.</p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>Não se esqueça de preencher todas as tratativas no <b style='color:#000'>painel de controle</b> <a href='https://bancobradesco.sharepoint.com/sites/BradescoExpresso-SejaumCorrespondente/Lists/Acompanhamento/AllItems.aspx?OR=Teams%2DHL&CT=1660049349608&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA3MDMwMDgxNCIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D'>Seja um Correspondente - Acompanhamento - Cliente</a></p>");
        sb.AppendLine("<br>");
        
        sb.AppendLine("<b style='color:#000'>DADOS DA EMPRESA</b>");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>RAZÃO SOCIAL: </b> " + correspondente.DadosEmpresa.RazaoSocial);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>RAMO DE ATIVIDADE: </b> " + correspondente.DadosEmpresa.RamoAtividade);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CNPJ: </b> " + correspondente.DadosEmpresa.Cnpj);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CEP: </b> " + correspondente.DadosEmpresa.Cep);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>ESTADO: </b> " + correspondente.DadosEmpresa.Estado);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CIDADE: </b> " + correspondente.DadosEmpresa.Cidade);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>BAIRRO: </b> " + correspondente.DadosEmpresa.Bairro);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>ENDEREÇO: </b> " + correspondente.DadosEmpresa.Endereco);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>NÚMERO: </b> " + correspondente.DadosEmpresa.Numero);
        sb.AppendLine("<br>");        
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>DADOS DO CONTATO</b>");
        sb.AppendLine("<br>");
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>NOME: </b> " + correspondente.DadosContato.Nome);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>E-MAIL: </b> " + correspondente.DadosContato.Email);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>TELEFONE: </b> " + correspondente.DadosContato.TelefoneNumero);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CLIENTE CORRENTISTA?: </b> " + (correspondente.DadosContato.Correntista == 1 ? "SIM" : "NÃO"));
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>AGÊNCIA: </b> " + correspondente.DadosContato.Agencia + " - " + correspondente.DadosContato.NomeAgencia);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>CONTA: </b> " + correspondente.DadosContato.Conta);
        sb.AppendLine("<br>");
        sb.AppendLine("<b style='color:#000'>AGÊNCIA MAIS PRÓXIMA DA EMPRESA: </b> " + correspondente.DadosContato.AgenciaProxima + " - " + correspondente.DadosContato.NomeAgenciaProxima);
        sb.AppendLine("<br>");
        if (!string.IsNullOrEmpty(correspondente.DadosContato.Observacao))
        {
            sb.AppendLine("<b style='color:#000'>OBSERVAÇÃO: </b> " + correspondente.DadosContato.Observacao);
            sb.AppendLine("<br>");
        }
        sb.AppendLine("<p>Qualquer dúvida estamos à disposição.</p>");
        sb.AppendLine("<br>");
        sb.AppendLine("<p>Classificação: <strong>INTERNA</strong> \"Este documento foi classificado pelo Departamento Bradesco Varejo/Bradesco Expresso/PA - Área Bradesco Expresso e o acesso está autorizado, exclusivamente, aos destinatários contidos nesta mensagem\".</p>");
        sb.AppendLine("<br>");        

        sb.AppendLine("</BODY>");
        sb.AppendLine("</HTML>");

        using (MailMessage email = new MailMessage())
        {
            try
            {
                email.From = new MailAddress("bradesco@infobradesco.com.br");
                email.Subject = "PREENCHIMENTO DO FORMULÁRIO - SEJA UM CORRESPONDENTE";
                email.Body = sb.ToString();
                email.IsBodyHtml = true;

                var listaEmailsCorrespondentes = ListarEmails(correspondente.DadosContato.Agencia);

                foreach (var item in listaEmailsCorrespondentes)
                {
                    email.To.Add(item);
                }

                SmtpClient ClienteSMTP = new SmtpClient(ConfigurationManager.AppSettings["SMTP.Host"].ToString(), 25);
                ClienteSMTP.UseDefaultCredentials = false;
                ClienteSMTP.EnableSsl = false;
                ClienteSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;

                ClienteSMTP.Send(email);
                return true;
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "alerta", "<script>alert('E-mail do gerente não enviado. " + ex.Message + " Tente novamente mais tarde.')</script>", false);
                return false;
            }
        }
    }

    public bool ValidaDigitoConta(string conta, int digito)
    {
        var lsoma = 0;
        var ipeso = 2;
        var dv_informado = digito;
        var dv_conta = conta;
        var tam = conta.Length;
        var digito_string = digito.ToString();

        var contaValue = new String[] { "", "", "", "", "", "", "", "" };

        for (int i = 0; i < tam; i++)
        {
            contaValue[i] = dv_conta.Substring(i, 1);
        }

        while (tam > 0)
        {
            digito_string = contaValue[--tam];
            digito = int.Parse(digito_string);
            if ((digito >= 0) && (digito <= 9))
            {
                lsoma = lsoma + (digito - 0) * ipeso;
                ipeso = ipeso + 1;
                if (ipeso > 7)
                { ipeso = 2; }
            }
        }

        lsoma %= 11;
        lsoma = 11 - lsoma;

        if ((lsoma == 11) || (lsoma == 10))
        {
            lsoma = 0;
        }

        return (dv_informado == lsoma);
    }

    private void ListarEstados()
    {
        ddlEstados.DataTextField = "Nome";
        ddlEstados.DataValueField = "UF";
        ddlEstados.DataSource = EstadoNegocio.EstadoSelectLst();
        ddlEstados.DataBind();
        ddlEstados.Items.Insert(0, new ListItem("Selecione um Estado", "-1"));
    }

    private void ListarRamos()
    {
        ddlRamos.DataTextField = "nomeRamo";
        ddlRamos.DataValueField = "ramoId";
        ddlRamos.DataSource = RamoNegocio.ListRamos();
        ddlRamos.DataBind();
        ddlRamos.Items.Insert(0, new ListItem("Selecione um Ramo", "-1"));
    }

    private List<string> ListarEmails(string codigoAgencia)
    {
        return EmailNegocio.ListEmails(codigoAgencia);
    }

    private void ListarOrigem()
    {
        ddlOrigem.DataTextField = "nomeOrigem";
        ddlOrigem.DataValueField = "origemId";
        ddlOrigem.DataSource = OrigemNegocio.ListarOrigem();
        ddlOrigem.DataBind();
        ddlOrigem.Items.Insert(0, new ListItem("Selecione onde nos encontrou", "-1"));
    }

    private string ObterAgencia(int step)
    {
        string retorno = "";
        string cep = "";

        if (step == 1)
        {
            cep = ipt_cep01.Text + ipt_cep02.Text;
        }
        else if (step == 2)
        {
            cep = txtCEPBusca.Text + txtCEPBusca2.Text;
        }

        if (String.IsNullOrEmpty(cep))
        {
            retorno = "O campo CEP é obrigatório.";
            return retorno;
        }

        if (HttpContext.Current.Request.IsSecureConnection)
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(this.CertificateValidationCallBack);

        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

        ServicoCep.Service servicecep = new ServicoCep.Service();
        BuscaAgenciasPorCEP.RededeAtendimento buscaagenciasporcep = new BuscaAgenciasPorCEP.RededeAtendimento();

        DataSet dsCoordenadas = servicecep.retLogradouroPorCep(cep);

        if (dsCoordenadas.Tables[0].Rows.Count > 0)
        {
            BuscaAgenciasPorCEP.PONTO[] dsAgencias = buscaagenciasporcep.ProcurarAgenciaPorCEP(cep, 3);

            if (dsAgencias.Length > 0)
            {
                for (int i = 0; i < 1; i++)
                {
                    if (dsAgencias[i].Codigo != 3750) //agencia next
                    {
                        if (step == 1)
                        {
                            Session["agenciaProximaEmpresa"] = agenciaProximaEmpresa = dsAgencias[i].Codigo.ToString();
                            Session["nomeAgenciaProximaEmpresa"] = nomeAgenciaProximaEmpresa = dsAgencias[i].Nome.ToString().Replace(" ", "");
                            retorno = "Ok";
                        }
                        else if (step == 2)
                        {                            
                            agenciaNaoCorrentista = dsAgencias[i].Codigo.ToString();
                            nomeAgenciaNaoCorrentista = dsAgencias[i].Nome.ToString().Replace(" ", "");
                            retorno = "Ok";
                        }
                    }
                }
            }
            else
            {
                retorno = "Não encontramos agências próximas a esse CEP. Insira um novo, por favor.";
            }
        }
        else
        {
            retorno = "CEP inválido. Insira um novo, por favor.";
        }

        return retorno;
    }

    private string ObterEndereco()
    {
        EnderecoUtil endererco = new EnderecoUtil();
        try
        {
            ServicoCep.Service servicoCep = new ServicoCep.Service();
            DataSet ds = servicoCep.retLogradouroPorCep(FormatarCallbackString());

            if (ds.Tables[0].Rows.Count > 0)
            {
                endererco.CEP = ds.Tables[0].Rows[0]["CEP"].ToString().Trim();
                endererco.LOGRADOURO = ds.Tables[0].Rows[0]["LOGRADOURO"].ToString().Trim();
                endererco.CIDADE = ds.Tables[0].Rows[0]["CIDADE"].ToString().Trim();
                endererco.BAIRRO = ds.Tables[0].Rows[0]["BAIRRO"].ToString().Trim();
                endererco.UF = ds.Tables[0].Rows[0]["UF"].ToString().Trim();                
            }            

            return endererco.ToString();
        }
        catch (Exception)
        {
            return null;
        }
    }

    private string FormatarCallbackString()
    {
        _strcallback = _strcallback.Replace("-", "").Replace("p1", "").Replace("p2", "");
        return _strcallback;
    }
    #endregion    
}
