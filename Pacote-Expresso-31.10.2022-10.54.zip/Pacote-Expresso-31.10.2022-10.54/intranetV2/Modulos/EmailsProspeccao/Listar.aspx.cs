﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modulos_EmailsCorrespondentes_Listar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            this.BuscaEmails();
        }
    }

    #region Eventos
    protected void rptTable_ItemDataBound(Object sender, RepeaterItemEventArgs e)
    {
        EmailsCorrespondentes item = (EmailsCorrespondentes)e.Item.DataItem;
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            HiddenField hdnID = (HiddenField)e.Item.FindControl("hdnID");
            Label ltlAgencia = (Label)e.Item.FindControl("ltlAgencia");
            Literal ltlEmail = (Literal)e.Item.FindControl("ltlEmail");

            ltlAgencia.Text = item.Agencia;
            ltlEmail.Text = item.Email;
        }
    }

    protected void btnLimpar_Click(object sender, EventArgs e)
    {
        txtAgencia.Text = String.Empty;
        txtEmail.Text = String.Empty;

        this.BuscaEmails();
    }

    protected void btnBuscar_Click(object sender, EventArgs e)
    {
        this.BuscaEmails(txtAgencia.Text.TrimStart('0'), txtEmail.Text);
    }

    protected void btnNovo_Click(object sender, EventArgs e)
    {
        var url = "../EmailsProspeccao/Novo.aspx";
        Page.Response.Redirect(url, true);
    }

    protected void btnExcluir_Click(object sender, EventArgs e)
    {
        var url = "../EmailsProspeccao/Excluir.aspx";
        Page.Response.Redirect(url, true);
    }

    protected void btnImportarBase_Click(object sender, EventArgs e)
    {
        var url = "../EmailsProspeccao/ImportarBase.aspx";
        Page.Response.Redirect(url, true);
    }

    protected void listPager_PageChanged(object sender, EventArgs e)
    {
        BindGrid();
    }

    #endregion

    #region Métodos
    private void BuscaEmails(string agencia = null, string email = null)
    {
        List<EmailsCorrespondentes> emails = new List<EmailsCorrespondentes>();

        emails = DOEmailsCorrespondentes.BuscarEmails(agencia, email);

        var emailsAgrupados = AgrupaEmails(emails);

        int totalRegistros = emailsAgrupados.Count;

        ltlQuantidadeRegistrosEncontrados.Text = totalRegistros.ToString();

        if (totalRegistros > 0)
        {
            listPager.PageSize = 5;
            listPager.DataSource = emailsAgrupados;
            listPager.DataBind();
            listPager.Visible = true;

            BindGrid();
        }
        else
        {
            listPager.Visible = false;
            rptTable.Visible = false;
        }
    }

    protected List<EmailsCorrespondentes> AgrupaEmails(List<EmailsCorrespondentes> emails)
    {
        List<KeyValuePair<string, string>> listaCompleta = new List<KeyValuePair<string, string>>();
        List<EmailsCorrespondentes> emailsCorrespondentes = new List<EmailsCorrespondentes>();
        Dictionary<string, string> agencias = new Dictionary<string, string>();
        EmailsCorrespondentes obj = new EmailsCorrespondentes();

        foreach (var item in emails)
        {
            listaCompleta.Add(new KeyValuePair<string, string>(item.Agencia, item.Email));
        }

        foreach (var item in listaCompleta)
        {
            if (!agencias.ContainsKey(item.Key))
            {
                agencias.Add(item.Key, item.Value + "\n");
            }
            else
            {
                agencias[item.Key] += item.Value + "\n";
            }
        }

        foreach (var item in agencias)
        {
            obj.Agencia = item.Key;
            obj.Email = item.Value;

            emailsCorrespondentes.Add(obj);

            obj = new EmailsCorrespondentes();
        }

        return emailsCorrespondentes;
    }

    private void BindGrid()
    {
        listPager.PageSize = 5;

        rptTable.DataSource = listPager.PageDataItems;
        rptTable.DataBind();

        bool hasData = false;

        listPager.Visible = (listPager.PageCount > 1);
        if (listPager.DataSource != null)
        {
            if (rptTable.Items.Count > 0)
            {
                hasData = true;
            }
        }

        rptTable.Visible = hasData;
    }

    #endregion
}