﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modulos_EmailsProspeccao_ImportarBase : System.Web.UI.Page
{
    List<string> emailsGestores;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnVoltar_Click(object sender, EventArgs e)
    {
        var url = "../EmailsProspeccao/Listar.aspx";
        Page.Response.Redirect(url, true);
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
            string extension = Path.GetExtension(FileUpload1.PostedFile.FileName);
            string folderPath = "/Uploads/EmailsProspeccao/";
            string filePath = Server.MapPath(folderPath + fileName);
            folderPath = Server.MapPath(folderPath);

            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            FileUpload1.SaveAs(filePath);

            DataTable dt = CreateDataTableEmails();

            if (dt.Rows.Count > 0 && dt.Columns.Count > 0)
            {
                InserirEmailsSupervisores(dt);
                InserirEmailsGestores(emailsGestores);

                AtualizarMensagemSucesso();
            }
            else
            {
                AtualizarMensagemErro();
            }

            File.Delete(filePath);            
        }
    }

    public DataTable CreateDataTableEmails()
    {
        using (XLWorkbook workBook = new XLWorkbook(FileUpload1.PostedFile.InputStream))
        {
            IXLWorksheet planilha = workBook.Worksheet(1);
            DataTable dt = new DataTable();
            bool firstRow = true;
            emailsGestores = new List<string>();

            foreach (IXLRow row in planilha.Rows())
            {
                if (firstRow)
                {
                    foreach (IXLCell cell in row.Cells())
                    {
                        if (cell.Address.ColumnLetter == "A")
                            if (cell.Value.ToString() != "AGENCIA")
                                break;

                        if (cell.Address.ColumnLetter == "B")
                            if (cell.Value.ToString() != "EMAIL_SUPERVISOR")
                                break;

                        if (cell.Address.ColumnLetter == "C")
                            if (cell.Value.ToString() != "EMAIL_GESTOR")
                                break;

                        if (cell.Address.ColumnLetter != "C")
                            dt.Columns.Add(cell.Value.ToString());
                    }
                    firstRow = false;
                }
                else
                {
                    dt.Rows.Add();
                    int i = 0;
                    string agencia;

                    foreach (IXLCell cell in row.Cells())
                    {
                        if (cell.Address.ColumnLetter == "A")
                            dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();

                        if (cell.Address.ColumnLetter == "B")
                        {
                            agencia = dt.Rows[dt.Rows.Count - 1][0].ToString();

                            string[] emailsSupervisores = tratarEmails(cell.Value.ToString());

                            for (int j = 0; j < emailsSupervisores.Length; j++)
                            {
                                dt.Rows[dt.Rows.Count - 1][i] = emailsSupervisores[j];
                                dt.Rows[dt.Rows.Count - 1][i - 1] = agencia;

                                if (j < emailsSupervisores.Length - 1)
                                    dt.Rows.Add();
                            }
                        }

                        if (cell.Address.ColumnLetter == "C")
                        {
                            if (emailsGestores.Count == 0)
                                emailsGestores = tratarEmails(cell.Value.ToString()).ToList();
                        }

                        i++;
                    }
                }
            }
            return dt;
        }
    }

    public string[] tratarEmails(string emails)
    {
        List<string> emailsSupervisorValidados = new List<string>();
        string[] emailsSupervisor = emails.Split(';');

        for (int i = 0; i < emailsSupervisor.Length; i++)
        {
            var emailAux = emailsSupervisor[i].Trim().ToLower();

            if (validarEmail(emailAux))
            {
                emailsSupervisorValidados.Add(emailAux);
            }
        }

        return emailsSupervisorValidados.ToArray();
    }

    public bool validarEmail(string email)
    {
        string expression = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
        Match match = Regex.Match(email, expression, RegexOptions.IgnoreCase);

        return match.Success;
    }

    public void InserirEmailsSupervisores(DataTable dt)
    {
        int id = DOEmailsCorrespondentes.InserirEmailSupervisores(dt);
    }

    public void InserirEmailsGestores(List<string> emailsGestores)
    {
        foreach (var email in emailsGestores)
        {
            int id = DOEmailsCorrespondentes.InserirEmailTodos(email);
        }
    }

    public void AtualizarMensagemSucesso()
    {
        lblMessage.Text = "Importação de e-mails realizada com sucesso!";
        lblMessage.ForeColor = System.Drawing.Color.Green;
        lblMessage.Visible = true;
    }

    public void AtualizarMensagemErro()
    {
        lblMessage.Text = "Arquivo inválido! Corrija o nome das colunas.";
        lblMessage.ForeColor = System.Drawing.Color.Red;
        lblMessage.Visible = true;
    }
}