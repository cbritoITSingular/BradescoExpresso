﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modulos_Consultores_Editar : System.Web.UI.Page
{
    #region Constantes
    private const int _IdSecao = 7;
    private const int _IdSecaoFuncionalidade_RevisaoAutomatica = 1;
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            this.IniciaTela();
            CarregarObjetos(Utilitarios.TipoTransacao.Limpar);

            if (Request.QueryString["Id"] != null)
            {
                Codigo = Convert.ToInt32(Request.QueryString["Id"]);
                gobjConsultor = DOConsultor.Obter(Codigo);
                CarregarObjetos(Utilitarios.TipoTransacao.Carregar);

                CarregaMunicipiosConsultor(Codigo);
            }

            if (Request.QueryString["VanId"] != null)
            {
                CodigoVan = Convert.ToInt32(Request.QueryString["VanId"]);
            }
        }
    }


    #region Variáveis
    public int Codigo
    {
        get { return (int)(ViewState["Codigo"] ?? ""); }
        set { ViewState["Codigo"] = value; }
    }
    public int CodigoVan
    {
        get { return (int)(ViewState["CodigoVan"] ?? ""); }
        set { ViewState["CodigoVan"] = value; }
    }
    private Consultor gobjConsultor;
    #endregion

    #region Eventos
    protected void btnCancelar_Click(object sender, EventArgs e)
    {
        Response.Redirect("Listar.aspx");
    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        Salvar();
    }

    protected void ddlEstado_SelectedIndexChanged(object sender, EventArgs e)
    {
        CarregarMunicipios();
    }

    protected void ddlUFSede_SelectedIndexChanged(object sender, EventArgs e)
    {
        CarregarMunicipiosSede();
    }

    protected void ddlSegmento_SelectedIndexChanged(object sender, EventArgs e)
    {
        CarregarSegmentoAgencia();
    }

    protected void ddlGerenciaRegional_SelectedIndexChanged(object sender, EventArgs e)
    {
        CarregarGerenciaRegional();
    }

    protected void btnAddCidade_Click(object sender, EventArgs e)
    {
        List<ConsultorCidade> listConsultorCidade = CarregarMunicipiosSelecionados();
        if (ddlCidade.SelectedValue != "")
        {
            if (!(from c in listConsultorCidade where c.IdCidade == Convert.ToInt32(ddlCidade.SelectedValue) select c).Any())
            {
                ConsultorCidade c = new ConsultorCidade();
                c.IdCidade = Convert.ToInt32(ddlCidade.SelectedValue);
                c.IdConsultor = Codigo;
                c.NomeCidadeEstado = ddlEstado.SelectedItem.Text + " - " + ddlCidade.SelectedItem.Text;
                listConsultorCidade.Add(c);
                Session["municipios"] = listConsultorCidade;
                CarregaMunicipiosConsultor(Codigo);
            }
        }
    }

    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            ImageButton img = (ImageButton)e.Row.FindControl("imgExcluir0");
            img.Attributes.Add("Onclick", "return confirm('" + Resources.Textos.Texto_Confirma_Exclusao + "')");
            img.CommandArgument = e.Row.RowIndex.ToString();
        }
    }

    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "excluir")
        {
            int index = Convert.ToInt32(e.CommandArgument);
            List<ConsultorCidade> listConsultorCidade = CarregarMunicipiosSelecionados();
            listConsultorCidade.RemoveAt(index);
            Session["municipios"] = listConsultorCidade;
            CarregaMunicipiosConsultor(Codigo);
        }
    }

    protected void txtCpf_TextChanged(object sender, EventArgs e)
    {
        if (!String.IsNullOrWhiteSpace(txtCpf.Text))
        {
            string strMensagemErroCpf = ValidaCPF();

            if (!String.IsNullOrWhiteSpace(strMensagemErroCpf))
            {
                //CPF digitado é inválido
                ((Manager_Interna)Master).ExibirMensagem(strMensagemErroCpf);
            }
        }
    }
    #endregion

    #region Métodos

    private void IniciaTela()
    {
        try
        {
            this.rfvNome.Text = Resources.Textos.Texto_Campo_Obrigatorio;
            this.rfvCpf.Text = Resources.Textos.Texto_Campo_Obrigatorio;
            this.rfvTelefone.Text = Resources.Textos.Texto_Campo_Obrigatorio;
            this.rfvCelular.Text = Resources.Textos.Texto_Campo_Obrigatorio;

            this.btnAddCidade.Text = Resources.Textos.Modulo_Consultor_Relacionar_Cidade;

            this.CarregarEstados();
            this.CarregarUFSede();
            this.CarregarSegmento();
            this.CarregarDiretoriaRegional();
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarObjetos(Utilitarios.TipoTransacao objTipoTransacao)
    {
        switch (objTipoTransacao)
        {
            //Novo Usuario
            case Utilitarios.TipoTransacao.Limpar:
                Codigo = 0;

                txtNome.Text = string.Empty;
                txtCpf.Text = string.Empty;
                txtTelefone.Text = string.Empty;
                txtCelular.Text = string.Empty;

                Session.Remove("municipios");

                txtCpf.Enabled = true;

                break;
            //Carregar Dados do Usuario
            case Utilitarios.TipoTransacao.Salvar:

                if (gobjConsultor == null)
                {
                    gobjConsultor = new Consultor();
                }

                gobjConsultor.ID = Codigo;
                gobjConsultor.IdVan = CodigoVan;
                gobjConsultor.Nome = txtNome.Text;
                gobjConsultor.Cpf = txtCpf.Text.Replace(".", "").Replace("-", "");
                gobjConsultor.Telefone = txtTelefone.Text;
                gobjConsultor.Telefone2 = txtCelular.Text;
                gobjConsultor.Ativo = true;
                gobjConsultor.Segmento = ddlSegmento.SelectedValue.ToString() == "0" ? null : ddlSegmento.SelectedValue.ToString();
                gobjConsultor.Agencia = ddlAgencia.SelectedValue.ToString() == "" ? null : ddlAgencia.SelectedValue.ToString();
                gobjConsultor.DiretoriaRegional = ddlDiretoriaRegional.SelectedValue.ToString() == "0" ? null : ddlDiretoriaRegional.SelectedValue.ToString();
                gobjConsultor.GerenciaRegional = ddlGerenciaRegional.SelectedValue.ToString() == "" ? null : ddlGerenciaRegional.SelectedValue.ToString();
                gobjConsultor.CEP = txtCep.Text == "" ? null : txtCep.Text;
                gobjConsultor.UFSede = ddlUFSede.SelectedValue.ToString() == "0" ? null : ddlUFSede.SelectedValue.ToString();
                gobjConsultor.MunicipioSede = ddlMunicipioSede.SelectedValue.ToString() == "" ? null : ddlMunicipioSede.SelectedValue.ToString();
                gobjConsultor.Revisado = DOAcessoFuncionalidade.VerificaAcessoFuncionalidade(((Manager_Interna)Master).UsuarioLogado().Id, _IdSecao, _IdSecaoFuncionalidade_RevisaoAutomatica);
                gobjConsultor.Cidades = CarregarMunicipiosSelecionados();

                break;
            //Descarregar Dados do Usuario
            case Utilitarios.TipoTransacao.Carregar:

                txtNome.Text = gobjConsultor.Nome;
                txtCpf.Text = Utilitarios.Formatacao.campos.FormataCpf(gobjConsultor.Cpf);
                txtTelefone.Text = gobjConsultor.Telefone;
                txtCelular.Text = gobjConsultor.Telefone2;

                if (!String.IsNullOrEmpty(gobjConsultor.CEP))
                    txtCep.Text = gobjConsultor.CEP;

                if (!String.IsNullOrEmpty(gobjConsultor.Segmento) && gobjConsultor.Segmento != "0")
                {
                    ddlSegmento.Items.FindByText(gobjConsultor.Segmento).Selected = true;
                    CarregarSegmentoAgencia();
                    ddlAgencia.SelectedItem.Text = gobjConsultor.Agencia;
                    ddlAgencia.SelectedValue = gobjConsultor.Agencia;
                }

                if (!String.IsNullOrEmpty(gobjConsultor.DiretoriaRegional) && gobjConsultor.DiretoriaRegional != "0")
                {
                    ddlDiretoriaRegional.Items.FindByText(gobjConsultor.DiretoriaRegional).Selected = true;
                    CarregarGerenciaRegional();
                }

                if (!String.IsNullOrEmpty(gobjConsultor.GerenciaRegional) && gobjConsultor.GerenciaRegional != "0")
                {
                    ddlGerenciaRegional.SelectedItem.Text = gobjConsultor.GerenciaRegional;
                    ddlGerenciaRegional.SelectedValue = gobjConsultor.GerenciaRegional;
                }

                if (!String.IsNullOrEmpty(gobjConsultor.UFSede) && gobjConsultor.UFSede != "0")
                {
                    ddlUFSede.Items.FindByText(gobjConsultor.UFSede).Selected = true;
                    CarregarMunicipiosSede();
                    ddlMunicipioSede.SelectedItem.Text = gobjConsultor.MunicipioSede;
                    ddlMunicipioSede.SelectedValue = gobjConsultor.MunicipioSede;
                }

                txtCpf.Enabled = false;
                break;
        }
    }

    private void Salvar()
    {
        try
        {
            this.CarregarObjetos(Utilitarios.TipoTransacao.Salvar);

            if (gobjConsultor.Cidades.Any())
            {
                if (Codigo == 0)
                {
                    string strMensagemErroCpf = ValidaCPF();

                    if (!String.IsNullOrWhiteSpace(strMensagemErroCpf))
                    {
                        //CPF digitado é inválido
                        ((Manager_Interna)Master).ExibirMensagem(strMensagemErroCpf);
                    }
                    else
                    {
                        //Envia para aprovação somente se revisado != true
                        if (gobjConsultor.Revisado)
                            DOConsultor.Inserir(gobjConsultor);
                        else
                            DOConsultorAprovacao.Inserir(gobjConsultor);

                        Response.Redirect("Listar.aspx?sucesso=1");
                    }
                }
                else
                {

                    //Envia para aprovação somente se revisado != true
                    if (gobjConsultor.Revisado)
                        DOConsultor.Atualizar(gobjConsultor); // Atualiza diretamente o registro
                    else
                        DOConsultorAprovacao.Inserir(gobjConsultor, Codigo); // Envia para aprovação

                    Response.Redirect("Listar.aspx?sucesso=2");
                }
            }
            else
            {
                //Selecionar ao menos uma cidade
                ((Manager_Interna)Master).ExibirMensagem(Resources.Textos.Modulo_Consultor_Selecione_Cidade);
            }
        }
        catch (SqlException sqlEx)
        {
            //"Cannot insert duplicate key row in object"
            if (sqlEx.Number == 2627)
                ((Manager_Interna)Master).ExibirMensagem(String.Format(Resources.Textos.Modulo_Consultor_Cpf_Existente, txtCpf.Text));
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarMunicipios()
    {
        try
        {
            if (ddlEstado.SelectedIndex > 0)
            {
                ddlCidade.DataSource = DOCidade.Listar(ddlEstado.SelectedValue);
                ddlCidade.DataTextField = "Nome";
                ddlCidade.DataValueField = "ID";
                ddlCidade.DataBind();
            }
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarUFSede()
    {
        try
        {
            ddlUFSede.DataSource = DOUFSede.Listar();
            ddlUFSede.DataTextField = "Nome";
            ddlUFSede.DataValueField = "Nome";
            ddlUFSede.DataBind();
            ddlUFSede.Items.Insert(0, new ListItem(Resources.Textos.Texto_Selecione, "0"));
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarSegmento()
    {
        try
        {
            ddlSegmento.DataSource = DOSegmento.Listar();
            ddlSegmento.DataTextField = "Segmento";
            ddlSegmento.DataValueField = "Segmento";
            ddlSegmento.DataBind();
            ddlSegmento.Items.Insert(0, new ListItem(Resources.Textos.Texto_Selecione, "0"));
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarDiretoriaRegional()
    {
        try
        {
            ddlDiretoriaRegional.DataSource = DODiretoriaRegional.Listar();
            ddlDiretoriaRegional.DataTextField = "DiretoriaRegional";
            ddlDiretoriaRegional.DataValueField = "DiretoriaRegional";
            ddlDiretoriaRegional.DataBind();
            ddlDiretoriaRegional.Items.Insert(0, new ListItem(Resources.Textos.Texto_Selecione, "0"));
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarMunicipiosSede()
    {
        try
        {
            if (ddlUFSede.SelectedIndex > 0)
            {
                ddlMunicipioSede.DataSource = DOMunicipioSede.Listar(ddlUFSede.SelectedValue);
                ddlMunicipioSede.DataTextField = "Municipio";
                ddlMunicipioSede.DataValueField = "Municipio";
                ddlMunicipioSede.DataBind();
            }
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarEstados()
    {
        try
        {
            ddlEstado.DataSource = DOEstado.Listar();
            ddlEstado.DataTextField = "Nome";
            ddlEstado.DataValueField = "Nome";
            ddlEstado.DataBind();
            ddlEstado.Items.Insert(0, new ListItem(Resources.Textos.Texto_Selecione, "0"));
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarSegmentoAgencia()
    {
        try
        {
            if (ddlSegmento.SelectedIndex > 0)
            {
                ddlAgencia.DataSource = DOSegmentoAgencia.Listar(ddlSegmento.SelectedValue);
                ddlAgencia.DataTextField = "NomeAgencia";
                ddlAgencia.DataValueField = "NomeAgencia";
                ddlAgencia.DataBind();
            }
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private void CarregarGerenciaRegional()
    {
        try
        {
            if (ddlDiretoriaRegional.SelectedIndex > 0)
            {
                ddlGerenciaRegional.DataSource = DOGerenciaRegional.Listar(ddlDiretoriaRegional.SelectedValue);
                ddlGerenciaRegional.DataTextField = "GerenciaRegional";
                ddlGerenciaRegional.DataValueField = "GerenciaRegional";
                ddlGerenciaRegional.DataBind();
            }
        }
        catch (Exception ex)
        {
            //Chama o método para gravar erro
            ((Manager_Interna)Master).ExibirAlerta(ex);
        }
    }

    private List<ConsultorCidade> CarregarMunicipiosSelecionados()
    {
        List<ConsultorCidade> listConsultorCidade = new List<ConsultorCidade>();

        if (Session["municipios"] == null)
        {
            Session["municipios"] = listConsultorCidade;
        }
        listConsultorCidade = (List<ConsultorCidade>)Session["municipios"];
        return listConsultorCidade;
    }

    protected void CarregaMunicipiosConsultor(int codConsultor)
    {
        List<ConsultorCidade> listConsultorCidade = new List<ConsultorCidade>();
        if (Session["municipios"] == null && codConsultor > 0)
        {
            listConsultorCidade = CarregarMunicipiosSelecionados();
            List<ConsultorCidade> municipios = DOConsultorCidade.Listar(codConsultor);
            foreach (ConsultorCidade c in municipios)
            {
                listConsultorCidade.Add(c);
            }
            Session["municipios"] = listConsultorCidade;
        }
        listConsultorCidade = CarregarMunicipiosSelecionados();
        GridView2.DataSource = listConsultorCidade;
        GridView2.DataBind();
    }

    protected string ValidaCPF()
    {
        if (!(Utilitarios.Validacao.Campos.ValidaCPF(txtCpf.Text)))
            return Resources.Textos.Modulo_Consultor_Cpf_Invalido;
        else
        {
            //faço uma consulta pra ver se o cpf já não está cadastrado
            Consultor objConsultor = DOConsultor.Obter(txtCpf.Text.Replace(".", "").Replace("-", ""));

            if (objConsultor.ID == 0)
            {
                List<ConsultorAprovacao> lstConsultoresAprovacao = DOConsultorAprovacao.Listar();

                if (lstConsultoresAprovacao != null)
                {
                    if (lstConsultoresAprovacao.Any())
                    {
                        if ((from i in lstConsultoresAprovacao where i.Cpf == txtCpf.Text.Replace(".", "").Replace("-", "") select i).Any())
                        {
                            return String.Format(Resources.Textos.Modulo_Consultor_Cpf_Existente_Aprovacao, txtCpf.Text);
                        }
                    }
                }
                return string.Empty;
            }
            else
                return String.Format(Resources.Textos.Modulo_Consultor_Cpf_Existente, txtCpf.Text);
        }
    }

    #endregion
}