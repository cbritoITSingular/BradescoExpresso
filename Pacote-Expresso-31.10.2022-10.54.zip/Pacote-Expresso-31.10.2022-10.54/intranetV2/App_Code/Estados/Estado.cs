﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

[Serializable()]
public class Estado
{
    #region Propriedades
    public virtual string Nome { get; set; }
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["UF"], DBNull.Value)))
        {
            this.Nome = pobjIDataReader["UF"].ToString().Trim();
        }
    }

    #endregion
}