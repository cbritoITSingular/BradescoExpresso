﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de DOEmailsCorrespondentes
/// </summary>
public class DOEmailsCorrespondentes
{
	public DOEmailsCorrespondentes()
	{
		//
		// TODO: Adicionar lógica do construtor aqui
		//
	}

    public static List<EmailsCorrespondentes> BuscarEmails(string agencia = null, string email = null)
    {
		string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

		SqlCommand objComando = new SqlCommand("SPE_L_EMAIL_PROSPECCAO_TODOS");
		objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;

        if (!String.IsNullOrEmpty(agencia))
            objComando.Parameters.Add("@Agencia", SqlDbType.VarChar, 10).Value = agencia;

        if (!String.IsNullOrEmpty(email))
            objComando.Parameters.Add("@Email", SqlDbType.VarChar, 120).Value = email;

        try
        {
            //Abre Conexao
            objConexao.Open();

            //Declara variavel de retorno           
            List<EmailsCorrespondentes> objListEmailCorrespondente = new List<EmailsCorrespondentes>();
            EmailsCorrespondentes objEmailCorrespondente = default(EmailsCorrespondentes);

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objEmailCorrespondente = new EmailsCorrespondentes();
                objEmailCorrespondente.FromIDataReader(idrReader);
                objListEmailCorrespondente.Add(objEmailCorrespondente);
            }

            return objListEmailCorrespondente;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }

    public static void ExcluirEmail(int id)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_D_EMAIL_PROSPECCAO");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@Id", SqlDbType.Int).Value = id;

        try
        {
            //Abre Conexao           
            objConexao.Open();

            //Executa comando no banco de dados
            objComando.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }

    public static void ExcluirTodosEmails(string email)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_D_EMAIL_PROSPECCAO_TODOS");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@Email", SqlDbType.VarChar, 200).Value = email;

        try
        {
            //Abre Conexao           
            objConexao.Open();

            //Executa comando no banco de dados
            objComando.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }

    public static int InserirEmail(string agencia, string email)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_I_EMAIL_PROSPECCAO");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@Agencia", SqlDbType.VarChar, 4).Value = agencia;
        objComando.Parameters.Add("@Email", SqlDbType.VarChar, 200).Value = email;

        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Declara variavel de retorno
            int intRetorno = 0;

            //Executa comando no banco de dados
            intRetorno = objComando.ExecuteNonQuery();

            return intRetorno;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }

    public static int InserirEmailTodos(string email)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_I_EMAIL_PROSPECCAO_TODOS");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@Email", SqlDbType.VarChar, 200).Value = email;

        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Declara variavel de retorno
            int intRetorno = 0;

            //Executa comando no banco de dados
            intRetorno = objComando.ExecuteNonQuery();

            return intRetorno;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }

    public static int InserirEmailSupervisores(DataTable dt)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_I_EMAIL_SUPERVISOR");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;       
        objComando.Parameters.AddWithValue("@tableType", dt);

        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Declara variavel de retorno
            int intRetorno = 0;

            //Executa comando no banco de dados
            intRetorno = objComando.ExecuteNonQuery();

            return intRetorno;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
}