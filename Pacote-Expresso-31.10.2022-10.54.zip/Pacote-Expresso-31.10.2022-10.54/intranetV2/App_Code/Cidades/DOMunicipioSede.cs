﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de DOMunicipioSede
/// </summary>
public class DOMunicipioSede
{
    #region Listar
    public static List<MunicipioSede> Listar(string uf)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_L_MUNICIPIO_SEDE");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@UF", SqlDbType.Char, 2).Value = uf;

        try
        {
            //Abre Conexao
            objConexao.Open();

            //Declara variavel de retorno           
            List<MunicipioSede> objListCidade = new List<MunicipioSede>();
            MunicipioSede objCidade = default(MunicipioSede);

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objCidade = new MunicipioSede();
                objCidade.FromIDataReader(idrReader);
                objListCidade.Add(objCidade);
            }

            return objListCidade;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion
}