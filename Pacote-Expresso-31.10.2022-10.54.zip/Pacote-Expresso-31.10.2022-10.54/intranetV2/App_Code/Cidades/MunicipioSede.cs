﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de MunicipioSede
/// </summary>
public class MunicipioSede
{
    #region Propriedades
    public virtual string Municipio { get; set; }
    public virtual string UF { get; set; }
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["UF"], DBNull.Value)))
        {
            this.UF = pobjIDataReader["UF"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["Municipio"], DBNull.Value)))
        {
            this.Municipio = pobjIDataReader["Municipio"].ToString();
        }
    }

    #endregion
}