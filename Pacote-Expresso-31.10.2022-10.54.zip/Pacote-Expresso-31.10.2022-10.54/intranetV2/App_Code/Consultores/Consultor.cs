﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Consultor
/// </summary>

[Serializable()]
public class Consultor
{
    #region Propriedades
    public virtual int ID { get; set; }
    public virtual int IdVan { get; set; }
    public virtual string NomeFantasiaVan { get; set; }
    public virtual DateTime Data { get; set; }
    public virtual string Nome { get; set; }
    public virtual string Cpf { get; set; }
    public virtual string Telefone { get; set; }
    public virtual string Telefone2 { get; set; }
    public virtual bool Ativo { get; set; }
    public virtual bool Revisado { get; set; }
    public virtual string RevisadoDescricao { get; set; }
    public virtual int QuantidadeCidades { get; set; }
    public virtual List<ConsultorCidade> Cidades { get; set; }
    public virtual string Segmento { get; set; }
    public virtual string Agencia { get; set; }
    public virtual string DiretoriaRegional { get; set; }
    public virtual string GerenciaRegional { get; set; }
    public virtual string CEP { get; set; }
    public virtual string UFSede { get; set; }
    public virtual string MunicipioSede { get; set; }
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["Id"], DBNull.Value)))
        {
            this.ID = Convert.ToInt32(pobjIDataReader["Id"]);
        }

        if ((!object.ReferenceEquals(pobjIDataReader["ParceiroId"], DBNull.Value)))
        {
            this.IdVan = Convert.ToInt32(pobjIDataReader["ParceiroId"]);
        }

        if ((!object.ReferenceEquals(pobjIDataReader["nomeFantasia"], DBNull.Value)))
        {
            this.NomeFantasiaVan = pobjIDataReader["nomeFantasia"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["dataatual"], DBNull.Value)))
        {
            this.Data = Convert.ToDateTime(pobjIDataReader["dataatual"]);
        }

        if ((!object.ReferenceEquals(pobjIDataReader["nome"], DBNull.Value)))
        {
            this.Nome = pobjIDataReader["nome"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["cpf"], DBNull.Value)))
        {
            this.Cpf = pobjIDataReader["cpf"].ToString();
        }
        
        if ((!object.ReferenceEquals(pobjIDataReader["tel"], DBNull.Value)))
        {
            this.Telefone = pobjIDataReader["tel"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["tel2"], DBNull.Value)))
        {
            this.Telefone2 = pobjIDataReader["tel2"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["ativo"], DBNull.Value)))
        {
            this.Ativo = Convert.ToBoolean(pobjIDataReader["ativo"]);
        }

        if ((!object.ReferenceEquals(pobjIDataReader["revisado"], DBNull.Value)))
        {
            this.Revisado = Convert.ToBoolean(pobjIDataReader["revisado"]);
        }

        if ((!object.ReferenceEquals(pobjIDataReader["revisado"], DBNull.Value)))
        {
            this.RevisadoDescricao = Convert.ToBoolean(pobjIDataReader["revisado"])? "Sim" : "Não";
        }

        if ((!object.ReferenceEquals(pobjIDataReader["NUMCIDADES"], DBNull.Value)))
        {
            this.QuantidadeCidades = Convert.ToInt32(pobjIDataReader["NUMCIDADES"]);
        }

        if ((!object.ReferenceEquals(pobjIDataReader["Segmento"], DBNull.Value)))
        {
            this.Segmento = pobjIDataReader["Segmento"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["Agencia"], DBNull.Value)))
        {
            this.Agencia = pobjIDataReader["Agencia"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["DiretoriaRegional"], DBNull.Value)))
        {
            this.DiretoriaRegional = pobjIDataReader["DiretoriaRegional"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["GerenciaRegional"], DBNull.Value)))
        {
            this.GerenciaRegional = pobjIDataReader["GerenciaRegional"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["CEP"], DBNull.Value)))
        {
            this.CEP = pobjIDataReader["CEP"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["UFSede"], DBNull.Value)))
        {
            this.UFSede = pobjIDataReader["UFSede"].ToString();
        }

        if ((!object.ReferenceEquals(pobjIDataReader["MunicipioSede"], DBNull.Value)))
        {
            this.MunicipioSede = pobjIDataReader["MunicipioSede"].ToString();
        }
    }

    #endregion
}