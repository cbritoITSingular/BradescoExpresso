﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de SegmentoAgencia
/// </summary>
public class SegmentoAgencia
{
    #region Propriedades
    public virtual string NomeAgencia { get; set; }    
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["NomeAgencia"], DBNull.Value)))
        {
            this.NomeAgencia = pobjIDataReader["NomeAgencia"].ToString().Trim();
        }        
    }

    #endregion
}