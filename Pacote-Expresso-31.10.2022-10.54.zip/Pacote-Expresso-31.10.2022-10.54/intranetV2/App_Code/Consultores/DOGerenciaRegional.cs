﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de DOGerenciaRegional
/// </summary>
public class DOGerenciaRegional
{
    #region Listar
    public static List<ConsultorGerenciaRegional> Listar(string diretoria)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_L_GERENCIA_REGIONAL");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@DIRETORIA", SqlDbType.Char, 20).Value = diretoria;

        try
        {
            //Abre Conexao
            objConexao.Open();

            //Declara variavel de retorno           
            List<ConsultorGerenciaRegional> objListCidade = new List<ConsultorGerenciaRegional>();
            ConsultorGerenciaRegional objCidade = default(ConsultorGerenciaRegional);

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objCidade = new ConsultorGerenciaRegional();
                objCidade.FromIDataReader(idrReader);
                objListCidade.Add(objCidade);
            }

            return objListCidade;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion
}