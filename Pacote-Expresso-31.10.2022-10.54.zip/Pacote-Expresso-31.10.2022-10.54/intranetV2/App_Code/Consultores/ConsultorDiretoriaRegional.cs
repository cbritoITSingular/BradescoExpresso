﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de ConsultorDiretoriaRegional
/// </summary>
public class ConsultorDiretoriaRegional
{
    #region Propriedades
    public virtual string DiretoriaRegional { get; set; }
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["DiretoriaRegional"], DBNull.Value)))
        {
            this.DiretoriaRegional = pobjIDataReader["DiretoriaRegional"].ToString().Trim().ToUpper();
        }
    }

    #endregion
}