﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de DOSegmentoAgencia
/// </summary>
public class DOSegmentoAgencia
{
    #region Listar
    public static List<SegmentoAgencia> Listar(string segmento)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_L_SEGMENTO_AGENCIA");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@SEGMENTO", SqlDbType.Char, 10).Value = segmento;

        try
        {
            //Abre Conexao
            objConexao.Open();

            //Declara variavel de retorno           
            List<SegmentoAgencia> objListCidade = new List<SegmentoAgencia>();
            SegmentoAgencia objCidade = default(SegmentoAgencia);

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objCidade = new SegmentoAgencia();
                objCidade.FromIDataReader(idrReader);
                objListCidade.Add(objCidade);
            }

            return objListCidade;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion
}