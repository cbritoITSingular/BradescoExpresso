﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Manager;
using System.Collections.Generic;

public class DOConsultor
{
    #region  Obter
    /// <summary>
    /// Obtém um consultor pelo Id
    /// </summary>
    /// <param name="pintId">Id</param>
    /// <returns></returns>
    public static Consultor Obter(int pintId)
    {

        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_L_CONSULTOR_ID");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;

        objComando.Parameters.Add("@ID", SqlDbType.Int).Value = pintId;

        try
        {
            objConexao.Open();

            Consultor objConsultor = new Consultor();

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objConsultor.FromIDataReader(idrReader);
            }

            return objConsultor;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }

    }
    #endregion

    #region  Obter por CPF
    /// <summary>
    /// Obtém um consultor ativo pelo CPF
    /// </summary>
    /// <param name="pstrCpf">cpf</param>
    /// <returns></returns>
    public static Consultor Obter(string pstrCpf)
    {

        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_L_CONSULTOR_CPF");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;

        objComando.Parameters.Add("@cpf", SqlDbType.VarChar,11).Value = pstrCpf;

        try
        {
            objConexao.Open();

            Consultor objConsultor = new Consultor();

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objConsultor.FromIDataReader(idrReader);
            }

            return objConsultor;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }

    }
    #endregion

    #region Listar
    /// <summary>
    /// Lista consultores de uma VAN
    /// </summary>
    /// <param name="pintCodVan">Codigo da VAN</param>
    public static List<Consultor> Listar(int pintCodVan)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_L_CONSULTOR");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@PARCEIROID", SqlDbType.Int).Value = pintCodVan;
        
        try
        {
            //Abre Conexao
            objConexao.Open();

            //Declara variavel de retorno           
            List<Consultor> objListConsultor = new List<Consultor>();
            Consultor objConsultor = default(Consultor);

            IDataReader idrReader = default(IDataReader);

            idrReader = objComando.ExecuteReader();

            while ((idrReader.Read()))
            {
                objConsultor = new Consultor();
                objConsultor.FromIDataReader(idrReader);
                objListConsultor.Add(objConsultor);
            }

            return objListConsultor;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion
    
    #region Inserir
    /// <summary>
    /// Insere um consultor
    /// </summary>
    /// <param name="pobjConsultor">Consultor</param>
    /// <returns></returns>
    public static int Inserir(Consultor pobjConsultor)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        // Comando de inclusão de novo consultor
        SqlCommand objComando = new SqlCommand("SPE_I_CONSULTOR");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@ParceiroId", SqlDbType.Int).Value = pobjConsultor.IdVan;
        objComando.Parameters.Add("@nome", SqlDbType.VarChar,200).Value = pobjConsultor.Nome;
        objComando.Parameters.Add("@cpf", SqlDbType.VarChar,11).Value = pobjConsultor.Cpf;
        objComando.Parameters.Add("@tel", SqlDbType.VarChar,20).Value = pobjConsultor.Telefone;
        objComando.Parameters.Add("@tel2", SqlDbType.VarChar,20).Value = pobjConsultor.Telefone2;
        objComando.Parameters.Add("@ativo", SqlDbType.Bit).Value = pobjConsultor.Ativo;
        objComando.Parameters.Add("@revisado", SqlDbType.Bit).Value = pobjConsultor.Revisado;
        objComando.Parameters.Add("@Segmento", SqlDbType.VarChar, 20).Value = pobjConsultor.Segmento;
        objComando.Parameters.Add("@Agencia", SqlDbType.VarChar, 150).Value = pobjConsultor.Agencia;
        objComando.Parameters.Add("@DiretoriaRegional", SqlDbType.VarChar, 100).Value = pobjConsultor.DiretoriaRegional;
        objComando.Parameters.Add("@GerenciaRegional", SqlDbType.VarChar, 100).Value = pobjConsultor.GerenciaRegional;
        objComando.Parameters.Add("@CEP", SqlDbType.VarChar, 20).Value = pobjConsultor.CEP;

        SqlTransaction objTransaction = null;

        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Cria uma transação
            objTransaction = objConexao.BeginTransaction();

            //Declara variavel de retorno
            int intRetorno = 0;

            //Executa comando 1 no banco de dados
            objComando.Transaction = objTransaction;
            intRetorno = Convert.ToInt32(objComando.ExecuteScalar());

            foreach (ConsultorCidade objConsultorCidade in pobjConsultor.Cidades) {
                SqlCommand objComandoCidade = new SqlCommand("SPE_I_CONSULTOR_MUNICIPIO");
                objComandoCidade.Connection = objConexao;
                objComandoCidade.CommandType = CommandType.StoredProcedure;
                objComandoCidade.Parameters.Add("@ConsultorId", SqlDbType.Int).Value = intRetorno;
                objComandoCidade.Parameters.Add("@codcidade", SqlDbType.Int).Value = objConsultorCidade.IdCidade;
                objComandoCidade.Parameters.Add("@nomecidade", SqlDbType.VarChar, 200).Value = objConsultorCidade.NomeCidadeEstado;
                objComandoCidade.Parameters.Add("@UFSede", SqlDbType.VarChar, 3).Value = pobjConsultor.UFSede;
                objComandoCidade.Parameters.Add("@MunicipioSede", SqlDbType.VarChar, 100).Value = pobjConsultor.MunicipioSede;

                objComandoCidade.Transaction = objTransaction;
                objComandoCidade.ExecuteNonQuery();
            }

            //Executa o commit na base de dados
            objTransaction.Commit();

            return intRetorno;

        }
        catch (Exception ex)
        {
            objTransaction.Rollback();
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion

    #region Atualizar
    /// <summary>
    /// Atualiza um consultor
    /// </summary>
    /// <param name="pobjConsultor">Consultor</param>
    /// <returns></returns>
    public static int Atualizar(Consultor pobjConsultor)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        // Comando de inclusão de novo consultor
        SqlCommand objComando = new SqlCommand("SPE_U_CONSULTOR");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;
        objComando.Parameters.Add("@ID", SqlDbType.Int).Value = pobjConsultor.ID ;
        objComando.Parameters.Add("@nome", SqlDbType.VarChar, 200).Value = pobjConsultor.Nome;
        objComando.Parameters.Add("@cpf", SqlDbType.VarChar, 11).Value = pobjConsultor.Cpf;
        objComando.Parameters.Add("@tel", SqlDbType.VarChar, 20).Value = pobjConsultor.Telefone;
        objComando.Parameters.Add("@tel2", SqlDbType.VarChar, 20).Value = pobjConsultor.Telefone2;
        objComando.Parameters.Add("@revisado", SqlDbType.Bit).Value = pobjConsultor.Revisado;
        objComando.Parameters.Add("@segmento", SqlDbType.VarChar, 200).Value = pobjConsultor.Segmento;
        objComando.Parameters.Add("@agencia", SqlDbType.VarChar, 200).Value = pobjConsultor.Agencia;
        objComando.Parameters.Add("@diretoriaregional", SqlDbType.VarChar, 200).Value = pobjConsultor.DiretoriaRegional;
        objComando.Parameters.Add("@gerenciaregional", SqlDbType.VarChar, 200).Value = pobjConsultor.GerenciaRegional;
        objComando.Parameters.Add("@cep", SqlDbType.VarChar, 200).Value = pobjConsultor.CEP;

        SqlTransaction objTransaction = null;

        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Cria uma transação
            objTransaction = objConexao.BeginTransaction();

            //Declara variavel de retorno
            int intRetorno = 0;

            //Executa comando de atualização de consultor no banco de dados
            objComando.Transaction = objTransaction;
            intRetorno = objComando.ExecuteNonQuery();
            
            //Executa comando de exclusão de vínculos anteriores
            SqlCommand objComandoExclusao = new SqlCommand("SPE_D_CONSULTOR_MUNICIPIO");
            objComandoExclusao.Connection = objConexao;
            objComandoExclusao.CommandType = CommandType.StoredProcedure;
            objComandoExclusao.Parameters.Add("@ConsultorId", SqlDbType.Int).Value = pobjConsultor.ID;
            
            objComandoExclusao.Transaction = objTransaction;
            objComandoExclusao.ExecuteNonQuery();
            
            foreach (ConsultorCidade objConsultorCidade in pobjConsultor.Cidades)
            {
                SqlCommand objComandoCidade = new SqlCommand("SPE_I_CONSULTOR_MUNICIPIO");
                objComandoCidade.Connection = objConexao;
                objComandoCidade.CommandType = CommandType.StoredProcedure;
                objComandoCidade.Parameters.Add("@ConsultorId", SqlDbType.Int).Value = pobjConsultor.ID;
                objComandoCidade.Parameters.Add("@codcidade", SqlDbType.Int).Value = objConsultorCidade.IdCidade;
                objComandoCidade.Parameters.Add("@nomecidade", SqlDbType.VarChar, 200).Value = objConsultorCidade.NomeCidadeEstado;
                objComandoCidade.Parameters.Add("@ufsede", SqlDbType.VarChar, 3).Value = pobjConsultor.UFSede;
                objComandoCidade.Parameters.Add("@municipiosede", SqlDbType.VarChar, 200).Value = pobjConsultor.MunicipioSede;

                objComandoCidade.Transaction = objTransaction;
                objComandoCidade.ExecuteNonQuery();
            }

            //Executa o commit na base de dados
            objTransaction.Commit();

            return intRetorno;

        }
        catch (Exception ex)
        {
            objTransaction.Rollback();
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion

    #region Atualizar
    /// <summary>
    /// Atualiza um consultor
    /// </summary>
    /// <param name="pobjConsultor">Consultor</param>
    /// <returns></returns>
    public static int Aprovar(int pintId)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_U_CONSULTOR_APROVACAO");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;

        //Define parametros da procedure
        objComando.Parameters.Add("@ID", SqlDbType.Int).Value = pintId;
        
        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Declara variavel de retorno
            int intRetorno = 0;

            //Executa comando no banco de dados
            intRetorno = objComando.ExecuteNonQuery();

            return intRetorno;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion

    #region Excluir
    public static void Excluir(int pintId)
    {
        string strConectionString = ConfigurationManager.ConnectionStrings["BradescoExpresso"].ConnectionString;
        SqlConnection objConexao = new SqlConnection(strConectionString);

        SqlCommand objComando = new SqlCommand("SPE_D_CONSULTOR");
        objComando.Connection = objConexao;
        objComando.CommandType = CommandType.StoredProcedure;

        //Define parametros da procedure               
        objComando.Parameters.Add("@ID", SqlDbType.Int).Value = pintId;
        objComando.Parameters.Add("@cpf", SqlDbType.VarChar).Value = Utilitarios.CriptografiaSeguranca.GerarSenha();

        try
        {
            //Abre conexão com o banco de dados
            objConexao.Open();

            //Executa comando no banco de dados
            objComando.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            //Fecha a conexao se aberta
            if (objConexao.State != ConnectionState.Closed)
            {
                objConexao.Close();
            }
        }
    }
    #endregion
}