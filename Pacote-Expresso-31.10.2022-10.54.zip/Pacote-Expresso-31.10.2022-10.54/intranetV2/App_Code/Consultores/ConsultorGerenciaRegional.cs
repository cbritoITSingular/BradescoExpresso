﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de ConsultorGerenciaRegional
/// </summary>
public class ConsultorGerenciaRegional
{
    #region Propriedades
    public virtual string GerenciaRegional { get; set; }
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["GerenciaRegional"], DBNull.Value)))
        {
            this.GerenciaRegional = pobjIDataReader["GerenciaRegional"].ToString().Trim().ToUpper();
        }
    }

    #endregion
}