﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Descrição resumida de ConsultorSegmento
/// </summary>
public class ConsultorSegmento
{
    #region Propriedades
    public virtual string Segmento { get; set; }
    #endregion

    #region FromIDataReader

    public void FromIDataReader(IDataReader pobjIDataReader)
    {
        if (pobjIDataReader == null)
        {
            return;
        }

        if ((!object.ReferenceEquals(pobjIDataReader["Segmento"], DBNull.Value)))
        {
            this.Segmento = pobjIDataReader["Segmento"].ToString().Trim();
        }
    }

    #endregion
}